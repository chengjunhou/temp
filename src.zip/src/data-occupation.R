temp = dt$DRV_DRIVER_OCCUPATION

dt[, DRV_DRIVER_OCCUPATION_bin:='Other']

dt[temp%in%c(
  'Certified Educational Professional',
  'Teachers/Librarian',
  'TN Education Association',
  'TN Retired Teachers Association'
), DRV_DRIVER_OCCUPATION_bin:='Certified Educational Professional']

dt[temp%in%c(
  'Certified Medical Professional',
  'TN Dental Association',
  'TN Medical Association',
  'TN Nurse Association',
  'TN Pharmacist Association'
), DRV_DRIVER_OCCUPATION_bin:='Certified Medical Professional']

dt[temp%in%c(
  'Craftsman',
  'Operators - all types',
  'Proprietors'
), DRV_DRIVER_OCCUPATION_bin:='Craft/Oper/Prop']

dt[temp%in%c(
  'Doctor',
  'Farm',
  'Homemaker',
  'Military'
), DRV_DRIVER_OCCUPATION_bin:='Low']

dt[temp%in%c(
  'Admin. Managerial',
  'Foreman',
  'Lawyers - Judges',
  'Management',
  'Selective Agency Employee',
  'Selective Employee',
  'Supervisors'
), DRV_DRIVER_OCCUPATION_bin:='Management']

dt[temp=='Retired', DRV_DRIVER_OCCUPATION_bin:='Retired']

dt[temp%in%c(
  'N/A',
  'None'
), DRV_DRIVER_OCCUPATION_bin:='None']

dt[temp%in%c(
  'Default/Other',
  'Empl. - Occ. Unknown',
  'Unemployed',
  'Unknown',
  'Unskilled'
), DRV_DRIVER_OCCUPATION_bin:='Unknown']



