################################
# GLM Fit #
################################
library(glmnet)


###### obtain meta ######
class.vec = sapply(dt[,mvar.vec,with=F], class)
meta = data.frame(class.vec)
meta$Col = rownames(meta)
meta$Nuniq = sapply(dt[,mvar.vec,with=F], function(x) length(unique(x)))
meta$Class = meta$class.vec
meta = meta[,c(2,4,3)]
rownames(meta) = seq(1,dim(meta)[1])
meta$Pmis = pmut.data.pmis(dt[,mvar.vec,with=F])


###### process missing ######
tt <- dt[,mvar.vec,with=F]
temp.vec = meta$Col[meta$Pmis>0]
temp = as.matrix(tt[,temp.vec,with=F])
temp[is.na(temp)] = 0
tt[, (temp.vec):=as.data.table(temp)]
tt[is.na(dt$VEH_UW_Score_DIFF),VEH_UW_Score_DIFF:=-1]

names(tt)[names(tt)%in%meta$Col[meta$Class=='character']] = paste0(
  names(tt)[names(tt)%in%meta$Col[meta$Class=='character']], "...")
MATA = model.matrix(~., tt)
rm(tt, temp, temp.vec)


###### glm fit ######
tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]

start.time = Sys.time()
glm.fit = glmnet(MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,], y, family = "binomial", alpha=1, nlambda=50)
Sys.time() - start.time

y.pred = predict(glm.fit, newx=MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,], type="response")
pmut.auc(y.oo, y.pred[,42], plot=FALSE)






xgb_params_1 = list(
  booster="gblinear",
  objective = "binary:logistic",            # binary classification
  eval_metric = "auc"                       # evaluation/loss metric
)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 39,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)

