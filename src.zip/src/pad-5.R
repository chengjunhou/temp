# double counting of MVR and CLUE

aaa = dt[DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT>0 & 
           grepl('ACCIDENT, AT FAULT',res.df$DRV_EVENT_CHARGE_TYPE_CD_CONCAT) &
           grepl('ABOVE THRESHOLD',res.df$DRV_EVENT_CHARGE_TYPE_CD_CONCAT), 
         .(QTE_QUOTE_POLICY_NUM,
           QTE_QUOTE_NUM,
           QTE_QUOTE_EFF_DTTM,
           QTE_QUOTE_EFF_YEAR,
           QTE_QUOTE_EFF_MONTH,
           QTE_INSURED_NAME,
           DRV_DRIVER_NAME,
           DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,
           DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT,
           DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
           DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
           DRV_EVENT_CHARGE_TYPE_CD_CONCAT)]



# CLUE_DUI
index = which(dt$DRV_EVENT_CLUE_CLASS_CTAB_MAJS>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT>0)
View(dt[index, .(QTE_QUOTE_POLICY_NUM,
                 QTE_QUOTE_NUM,
                 QTE_QUOTE_EFF_DTTM,
                 QTE_QUOTE_EFF_YEAR,
                 QTE_QUOTE_EFF_MONTH,
                 QTE_INSURED_NAME,
                 DRV_DRIVER_NAME,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT,
                 DRV_EVENT_CLUE_CLASS_CTAB_MAJS,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                 DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
                 DRV_EVENT_CHARGE_TYPE_CD_CONCAT)])


# MVR has accidient
index = grepl('ACCIDENT',res.df$DRV_EVENT_CHARGE_TYPE_CD_CONCAT)
index = dt$DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==1 & index
View(dt[index, .(QTE_QUOTE_POLICY_NUM,
                 QTE_QUOTE_NUM,
                 QTE_QUOTE_EFF_DTTM,
                 QTE_QUOTE_EFF_YEAR,
                 QTE_INSURED_NAME,
                 DRV_DRIVER_NAME,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,
                 DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                 DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
                 DRV_EVENT_CHARGE_TYPE_CD_CONCAT)])




