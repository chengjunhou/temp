library(data.table)
library(ggplot2)
library(pmut)


class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)
qte = fread("raw/qte-meta.csv")


###### quote-num filter ######
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:2)]
dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt[,KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR, DRV_DRIVER_NAME)]


###### create meta ######
meta = data.frame(class.vec)
meta$Col = rownames(meta)
meta$Nuniq = sapply(dt, function(x) length(unique(x)))[1:length(class.vec)]
meta$Class = meta$class.vec
meta = meta[,c(2,4,3)]
rownames(meta) = seq(1,dim(meta)[1])
meta$Pmis = pmut.data.pmis(dt)[1:length(class.vec)]
#write.csv(meta, "meta/mvr-full-sta.csv")


###### process data ######
dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]


# QTE_QUOTE_RECEIVED_DTTM
dt[, QTE_QUOTE_RECEIVED_DTTM_NA_ind:=0]
dt[QTE_QUOTE_RECEIVED_YEAR==0, QTE_QUOTE_RECEIVED_DTTM_NA_ind:=1]
dt[, QTE_QUOTE_RECEIVED_ADVANCE_MONTHS:=
     (QTE_QUOTE_EFF_YEAR-QTE_QUOTE_RECEIVED_YEAR)*12 + (QTE_QUOTE_EFF_MONTH-month(as.IDate(QTE_QUOTE_RECEIVED_DTTM)))]
#dt[QTE_QUOTE_RECEIVED_ADVANCE_MONTHS<(-1), QTE_QUOTE_RECEIVED_ADVANCE_MONTHS:=(-1)]
#dt[QTE_QUOTE_RECEIVED_ADVANCE_MONTHS>24, QTE_QUOTE_RECEIVED_ADVANCE_MONTHS:=24]
dt[QTE_QUOTE_RECEIVED_ADVANCE_MONTHS<(-1)|QTE_QUOTE_RECEIVED_ADVANCE_MONTHS>24, QTE_QUOTE_RECEIVED_DTTM_NA_ind:=1]

dt[!QTE_HOME_OWNERSHIP_CODE%in%c('N','Y','S','H','W','L'),QTE_HOME_OWNERSHIP_CODE:='N']

# QTE_YEARS_PRIOR_CARRIER
dt[, QTE_YEARS_PRIOR_CARRIER_num:=999]
dt[QTE_YEARS_PRIOR_CARRIER%in%c('N/A','NO NEED'), QTE_YEARS_PRIOR_CARRIER_num:=0]
dt[QTE_YEARS_PRIOR_CARRIER=='Less Than 1 year', QTE_YEARS_PRIOR_CARRIER_num:=0.5]
dt[QTE_YEARS_PRIOR_CARRIER=='Greater or equal to 1, less than 2 years', QTE_YEARS_PRIOR_CARRIER_num:=1.5]
dt[QTE_YEARS_PRIOR_CARRIER=='Greater or equal to 2, less than 3 years', QTE_YEARS_PRIOR_CARRIER_num:=2.5]
dt[QTE_YEARS_PRIOR_CARRIER=='Greater or equal to 3, less than 4 years', QTE_YEARS_PRIOR_CARRIER_num:=3.5]
dt[QTE_YEARS_PRIOR_CARRIER=='Greater or equal to 4, less than 5 years', QTE_YEARS_PRIOR_CARRIER_num:=4.5]
dt[QTE_YEARS_PRIOR_CARRIER=='Greater or equal to 5', QTE_YEARS_PRIOR_CARRIER_num:=5.9]
# QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY
dt[, QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=999]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY%in%c('N/A','NO NEED','None'), QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=0]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Less Than 1 Year', QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=0.5]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Greater Or Equal To 1, Less Than 2 Years', 
   QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=1.5]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Greater Or Equal To 2, Less Than 3 Years', 
   QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=2.5]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Greater Or Equal To 3, Less Than 4 Years', 
   QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=3.5]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Greater Or Equal To 4, Less Than 5 Years', 
   QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=4.5]
dt[QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY=='Greater Or Equal To 5', QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num:=5.9]

dt[!QTE_OTHER_AU_INS_CD%in%c('K','S','F','C','R','O','P','Y'), QTE_OTHER_AU_INS_CD:='N']

# COV_Edge_Endors_Ind
cov.vec = names(dt)[grep('COV_',names(dt))][19:25]
dt[is.na(COV_Edge_Endors_Ind)|COV_Edge_Endors_Ind=='',(cov.vec):='N']
rm(cov.vec)

dt[,VEH_Annual_Mileage_NA_ind:=0]
dt[is.na(VEH_Annual_Mileage_MAX),VEH_Annual_Mileage_NA_ind:=1]
dt[,VEH_Miles_to_Work_NA_ind:=0]
dt[is.na(VEH_Miles_to_Work_MAX),VEH_Miles_to_Work_NA_ind:=1]

dt[,VEH_Comp_Symbol_NA_ind:=0]
dt[is.na(VEH_Comp_Symbol_MAX),VEH_Comp_Symbol_NA_ind:=1]
dt[,VEH_Coll_Symbol_NA_ind:=0]
dt[is.na(VEH_Coll_Symbol_MAX),VEH_Coll_Symbol_NA_ind:=1]
dt[,VEH_Vehicle_Symbol_NA_ind:=0]
dt[is.na(VEH_Vehicle_Symbol_MAX),VEH_Vehicle_Symbol_NA_ind:=1]

dt[,VEH_UW_Score_NA_ind:=0]
dt[is.na(VEH_UW_Score_MAX),VEH_UW_Score_NA_ind:=1]
dt[,VEH_UW_Score_DIFF:=VEH_UW_Score_MAX-VEH_UW_Score_MIN]

dt[,VEH_Vehicle_Interest_Type_CTAB_LienNA_ind:=0]
dt[is.na(VEH_Vehicle_Interest_Type_CTAB_Lienholder_CNT),VEH_Vehicle_Interest_Type_CTAB_LienNA_ind:=1]

# DRV_DRIVER_MARITAL_STATUS
#dt[,DRV_DRIVER_MARITAL_STATUS_bin:=DRV_DRIVER_MARITAL_STATUS]
#dt[is.na(DRV_DRIVER_MARITAL_STATUS)|DRV_DRIVER_MARITAL_STATUS=='N/A'|DRV_DRIVER_MARITAL_STATUS=='',
#   DRV_DRIVER_MARITAL_STATUS_bin:='NA']
#dt[grep("Divorced",DRV_DRIVER_MARITAL_STATUS),DRV_DRIVER_MARITAL_STATUS_bin:='Divorced']
dt[,DRV_DRIVER_MARITAL_STATUS_bin:='Other']
dt[DRV_DRIVER_MARITAL_STATUS=='Married',DRV_DRIVER_MARITAL_STATUS_bin:='Married']
dt[DRV_DRIVER_MARITAL_STATUS=='Single',DRV_DRIVER_MARITAL_STATUS_bin:='Single']

# DRV_DRIVER_LICENSE_STATE
dt[DRV_DRIVER_LICENSE_STATE%in%c('','XX'),DRV_DRIVER_LICENSE_STATE:='NA']
dt[,DRV_DRIVER_LICENSE_STATE_diff:='N']
dt[DRV_DRIVER_LICENSE_STATE!=QTE_MAILING_ADDRESS_STATE_ABBREV,DRV_DRIVER_LICENSE_STATE_diff:='Y']

# DRV_DRIVER_LICENSE_DTTM
temp = as.IDate(dt$DRV_DRIVER_LICENSE_DTTM)
dt[,DRV_DRIVER_LICENSE_MONTHS_v1:=(QTE_QUOTE_EFF_YEAR-year(temp))*12 + (QTE_QUOTE_EFF_MONTH-month(temp))]

#dt[DRV_DRIVER_AWAY_AT_SCHOOL=='',DRV_DRIVER_AWAY_AT_SCHOOL:='No']
dt[,DRV_DRIVER_STUDENT_DISC_v1:='No'];dt[DRV_DRIVER_STUDENT_DISC%in%c('L','Yes; extended'),DRV_DRIVER_STUDENT_DISC_v1:='Yes']
dt[DRV_DRIVER_EXTENDED_APIP%in%c('','N/A'),DRV_DRIVER_EXTENDED_APIP:='MISS']
dt[,DRV_DRIVER_DRIVING_COURSE_v1:='No'];dt[DRV_DRIVER_DRIVING_COURSE=='Y-Yes',DRV_DRIVER_DRIVING_COURSE_v1:='Yes']
#dt[DRV_DRIVER_TRAINING=='',DRV_DRIVER_TRAINING:='No']
dt[DRV_DRIVER_ACCIDENT_CONVICTION_FREE_CD=='',DRV_DRIVER_ACCIDENT_CONVICTION_FREE_CD:='MISS']
#dt[DRV_DRIVER_OPERATOR_TYPE_DESC=='',DRV_DRIVER_OPERATOR_TYPE_DESC:='Prinicipal']

# DRV_PQUOTE_INSURED_SPOUSAL_IND DRV_PQUOTE_INSURED_TYPE_CD
dt[,DRV_DRIVER_TYPE_CD:='household-member']
dt[DRV_PQUOTE_INSURED_TYPE_CD=='INSD1',DRV_DRIVER_TYPE_CD:='name-insured']
dt[DRV_PQUOTE_INSURED_TYPE_CD=='INSD2'&DRV_PQUOTE_INSURED_SPOUSAL_IND=='Y',DRV_DRIVER_TYPE_CD:='second-spouse']
dt[DRV_PQUOTE_INSURED_TYPE_CD=='INSD2'&DRV_PQUOTE_INSURED_SPOUSAL_IND=='N',DRV_DRIVER_TYPE_CD:='second-non-spouse']
# DRV_CREDIT_SCORE_STG_DIFF
dt[, DRV_CREDIT_SCORE_STG_DIFF:=-1]; dt[, DRV_CREDIT_SCORE_STG_DIFF:=as.integer(DRV_CREDIT_SCORE_STG_DIFF)]
dt[!is.na(DRV_CREDIT_SCORE_STG), DRV_CREDIT_SCORE_STG_DIFF:=(DRV_PQUOTE_CREDIT_SCORE-DRV_CREDIT_SCORE_STG)]

temp.vec = names(dt)[grep('DRV_EVENT_DRIVER_EVENT_ADDED_BY',names(dt))][-3]
temp = as.matrix(dt[,temp.vec,with=F])
temp[is.na(temp)] = 0
dt[, (temp.vec):=as.data.table(temp)]

temp.vec = names(dt)[intersect(grep('DRV_EVENT_',names(dt)), grep('_POINTS_MAX',names(dt)))][-3]
temp = as.matrix(dt[,temp.vec,with=F])
temp[is.na(temp)] = 0
dt[, (temp.vec):=as.data.table(temp)]

temp.vec = names(dt)[grep('DRV_EVENT_CLUE_CLASS_CTAB',names(dt))]
temp = as.matrix(dt[,temp.vec,with=F])
temp[is.na(temp)] = 0
dt[, (temp.vec):=as.data.table(temp)]

# QTE_PREV_CARRIER
source('src/data-priorcarr.R')

# DRV_DRIVER_OCCUPATION
source('src/data-occupation.R')

rm(temp, temp.vec)



###### obtain inf.df res.df ######
inf.df = dt[,.(QTE_QUOTE_KEY,
               QTE_QUOTE_POLICY_NUM,
               QTE_QUOTE_NUM,
               QTE_QUOTE_EFF_DTTM,
               QTE_QUOTE_EFF_YEAR,
               QTE_QUOTE_EFF_MONTH,
               QTE_INSURED_NAME,
               DRV_DRIVER_NAME)]
res.df = dt[,.(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
               DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
               DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT,
               DRV_DRIVER_SDIP_PTS_NUM,
               DRV_DRIVER_ACCIDENT_CONVICTION_FREE_CD,
               DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
               DRV_EVENT_CHARGE_TYPE_CD_CONCAT,
               DRV_EVENT_NUM_OF_POINTS_CONCAT,
               DRV_EVENT_MVR_POINTS_MAX)]

res.df[, Y:=0]
res.df[DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT>0, Y:=1]
res.df[DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==0 & DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT>0 & 
         DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT<DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT, Y:=1]
inf.df[,Y:=res.df$Y]


source('src/vec-1.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]

temp = dt[,catg.vec,with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(dt[,num.vec,with=F]))
rm(temp)


