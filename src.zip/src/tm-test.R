library(tm)

df  = data.frame(num=c(1,2,3),ttt=c('asd,sdf','sdf,dfg','asd,sdf,dfg,dfg'))

docs = Corpus(VectorSource(df$ttt))
inspect(docs)

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
docs <- tm_map(docs, toSpace, ",")
inspect(docs)

dtm <- DocumentTermMatrix(docs)
m <- as.matrix(dtm)
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
head(d, 10)


