source('src/vec-1.R')


table(catg.vec %in% names(dt))
table(num.vec %in% names(dt))


apply(dt[,catg.vec,with=F], 2, function(x) sum(is.na(x)))
apply(dt[,catg.vec,with=F], 2, function(x) sum(x==''))

dt[, RES:=res.df$Y]


###### catg eda ######
pdf("doc/eda-catg.pdf", width=10, height=8)
zxc = as.data.frame(table(dt$QTE_MAILING_ADDRESS_STATE_ABBREV))
pmut.edap(dt[QTE_MAILING_ADDRESS_STATE_ABBREV%in%as.character(zxc$Var1[zxc$Freq>100])], catg.vec[1], "RES")

pmut.edap(dt, catg.vec[2:36], "RES")
dev.off()



###### num eda ######
pdf("doc/eda-num.pdf", width=10, height=8)
pmut.edap(dt, num.vec[1:3], "RES")

pmut.edap(dt[QTE_QUOTE_RECEIVED_ADVANCE_MONTHS>=0&QTE_QUOTE_RECEIVED_ADVANCE_MONTHS<=24], num.vec[4], "RES")

pmut.edap(dt, num.vec[5:6], "RES")

pmut.edap(dt[QTE_PRIOR_BI_CSL_LIMIT_AMT%in%c(0,1e+05,3e+05,5e+05)], num.vec[7], "RES")
zxc = as.data.frame(table(dt$QTE_PRIOR_BI_OCCURRENCE_LIMIT_AMT))
pmut.edap(dt[QTE_PRIOR_BI_OCCURRENCE_LIMIT_AMT%in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[8], "RES")
zxc = as.data.frame(table(dt$QTE_PRIOR_BI_PER_PERSON_LIMIT_AMT))
pmut.edap(dt[QTE_PRIOR_BI_PER_PERSON_LIMIT_AMT%in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[9], "RES")

pmut.edap(dt, num.vec[10:18], "RES")

zxc = as.data.frame(table(dt$COV_Medical_Payments ))
pmut.edap(dt[COV_Medical_Payments %in%as.character(zxc$Var1[zxc$Freq>800])], num.vec[19], "RES")

pmut.edap(dt, num.vec[20:22], "RES")

zxc = as.data.frame(table(dt$COV_Comprehensive_Deductible ))
pmut.edap(dt[COV_Comprehensive_Deductible %in%as.character(zxc$Var1[zxc$Freq>2000])], num.vec[23], "RES")
zxc = as.data.frame(table(dt$COV_Collision_Deductible ))
pmut.edap(dt[COV_Collision_Deductible %in%as.character(zxc$Var1[zxc$Freq>2000])], num.vec[24], "RES")
zxc = as.data.frame(table(dt$COV_Combined_Single_BI_Limit ))
pmut.edap(dt[COV_Combined_Single_BI_Limit %in%as.character(zxc$Var1[zxc$Freq>1000])], 'COV_Combined_Single_BI_Limit', "RES")
zxc = as.data.frame(table(dt$COV_UM_Combined_Single_BI_Limit ))
pmut.edap(dt[COV_UM_Combined_Single_BI_Limit %in%as.character(zxc$Var1[zxc$Freq>1000])], 'COV_UM_Combined_Single_BI_Limit', "RES")

pmut.edap(dt, num.vec[27:38], "RES")

pmut.edap(dt[!is.na(VEH_MVR_VEHICLE_KEY)], num.vec[39:41], "RES")

pmut.edap(dt, num.vec[42:54], "RES")

zxc = as.data.frame(table(dt$VEH_Annual_Mileage_MAX ))
pmut.edap(dt[VEH_Annual_Mileage_MAX %in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[55], "RES")
zxc = as.data.frame(table(dt$VEH_Annual_Mileage_MIN ))
pmut.edap(dt[VEH_Annual_Mileage_MIN %in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[56], "RES")
zxc = as.data.frame(table(dt$VEH_Annual_Mileage_AVG ))
pmut.edap(dt[VEH_Annual_Mileage_AVG %in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[57], "RES")
pmut.edap(dt, num.vec[58], "RES")

zxc = as.data.frame(table(dt$VEH_Miles_to_Work_MAX ))
pmut.edap(dt[VEH_Miles_to_Work_MAX %in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[59], "RES")
zxc = as.data.frame(table(dt$VEH_Miles_to_Work_MIN ))
pmut.edap(dt[VEH_Miles_to_Work_MIN %in%as.character(zxc$Var1[zxc$Freq>1000])], num.vec[60], "RES")
pmut.edap(dt, num.vec[61], "RES")

pmut.edap(dt, num.vec[62:76], "RES")
zxc = as.data.frame(table(dt$VEH_UW_Score_DIFF[dt$VEH_UW_Score_DIFF!=0] ))
pmut.edap(dt[VEH_UW_Score_DIFF %in%c('0',as.character(zxc$Var1[zxc$Freq>100]))], num.vec[77], "RES")

pmut.edap(dt, num.vec[78:94], "RES")
pmut.edap(dt, num.vec[95:127], "RES")
pmut.edap(dt, num.vec[128:130], "RES")

pmut.edap(dt, num.vec[131:155], "RES")
pmut.edap(dt, 'DRV_EVENT_CLUE_CLASS_CTAB_ALLO', "RES")
dev.off()


