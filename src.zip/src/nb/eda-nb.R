
dt[,RES:=inf.df$Y]

pmut.edap.disc(dt, 'DRV_EVENT_CLUE_POINTS_AVG', 'RES')
pmut.edap.disc(dt, 'DRV_EVENT_CLUE_POINTS_MAX', 'RES')
pmut.edap.disc(dt, 'DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT', 'RES')


###### AUC ######
aa=y.oo; pp=y.pred
zxc=fread('meta/1113/Y18_Pred.csv');aa=zxc$Y; pp=zxc$Pred

ord <- order(pp, decreasing=TRUE)
aa <- aa[ord]
pp <- pp[ord]
x <- cumsum(!aa)/max(1,sum(!aa)) # FPR = x-axis
y <- cumsum(aa)/max(1,sum(aa))   # TPR = y-axis
# remove dups to achieve this.
dup <- c(pp[-1]>=pp[-length(pp)],
         FALSE)
# add in ideal endpoints just in case
x <- c(0,x[!dup],1)
y <- c(0,y[!dup],1)
# sum areas of segments
n <- length(y)
area <- sum( ((y[-1]+y[-n])/2) * (x[-1]-x[-n]) )

plotdat <- data.frame(FP=x,TP=y)
plotdat$mod <- "V2"
plot.df = plotdat

plotdat <- data.frame(FP=x,TP=y)
plotdat$mod <- "V1"
plot.df = rbind(plot.df,plotdat)

# auc plot
p1 <- ggplot(plot.df, aes(x=FP,y=TP,color=mod)) + geom_abline(intercept=0,slope=1) + geom_line(lwd=1) +
  labs(title="AUC Plot", x="false-positive rate", y="true-positive rate") +
  theme(legend.position="right", plot.title=element_text(hjust = 0.5))
print(p1)


