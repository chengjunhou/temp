library(data.table)
library(ggplot2)
library(pmut)
library(xgboost)
source('src/xgb2sql/onehot-script.R')
source('src/xgb2sql/script.R')


class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)


###### quote-num filter ######
qte = fread("raw/qte-meta.csv")
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:7)]

dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt[,KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR, DRV_DRIVER_NAME)]
rm(qte, qte.unq, qte.vec)

dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]
dt <- dt[!is.na(QTE_NUM_OF_VEHICLES_B),]
dt <- dt[order(QTE_QUOTE_POLICY_NUM, QTE_QUOTE_EFF_DTTM),]
source('src/nb/data-prep.R')


###### response re-make ######
inf.df = dt[,.(QTE_QUOTE_KEY,
               QTE_QUOTE_POLICY_NUM,
               QTE_QUOTE_EFF_DTTM,
               QTE_QUOTE_EFF_YEAR,
               QTE_QUOTE_EFF_MONTH,
               QTE_STATE=QTE_MAILING_ADDRESS_STATE_ABBREV,
               QTE_INSURED_NAME,
               DRV_DRIVER_NAME,
               DRV_DRIVER_KEY)]
res.df = dt[,.(DRV_EVENT_VALMVR_CNT,
               DRV_EVENT_VALMVR_ADDED_CONCAT,
               DRV_EVENT_VALMVR_VIOLATION_CONCAT,
               DRV_EVENT_VALMVR_CHARGE_DESC_CONCAT,
               DRV_EVENT_VALMVR_POINTS_CONCAT,
               DRV_EVENT_VALMVR_ADMIN_MESSAGE_CNT,
               DRV_EVENT_EXCMVR_CNT)]
res.df[is.na(DRV_EVENT_VALMVR_CNT),DRV_EVENT_VALMVR_CNT:=0]
res.df[is.na(DRV_EVENT_VALMVR_ADMIN_MESSAGE_CNT),DRV_EVENT_VALMVR_ADMIN_MESSAGE_CNT:=0]
inf.df[, Y:=0]
inf.df[res.df$DRV_EVENT_VALMVR_CNT>0 & res.df$DRV_EVENT_VALMVR_ADMIN_MESSAGE_CNT<res.df$DRV_EVENT_VALMVR_CNT, Y:=1]
#inf.df[,VALMVR_CNT:=res.df$DRV_EVENT_VALMVR_CNT]; inf.df[inf.df$Y==0,VALMVR_CNT:=0]


###### one-hot encode ######
source('src/nb/vec-nb.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]
#apply(dt[,catg.vec,with=F], 2, function(x) sum(is.na(x)))
#apply(dt[,catg.vec,with=F], 2, function(x) sum(x==''))

#catg.vec = c(catg.vec, 'QTE_PREV_CARRIER_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_OCCUPATION_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_LICENSE_STATE')
#num.vec = c(num.vec, 'QTE_TOTAL_PREMIUM')
#num.vec = c(num.vec, 'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')

temp = dt[, c(catg.vec,num.vec,evna.vec,evnb.vec), with=F]
out <- fun_data_prep(temp)
rm(temp)

### generate sql script with only varaibles that are used
#mvar.vec = readRDS('meta/mvar.vec')
#temp = dt[, mvar.vec, with=F]
#out <- fun_data_prep(temp, output_file_name='mvr_onehot.txt')

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = out$model.matrix[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = out$model.matrix[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec, out)
gc()



###### modeling ######
xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.29,                               # learning rate
  max.depth =  9,                           # max tree depth
  gamma = 15,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)

start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 48,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)


# optimal one obtained at iteration 37
importance_matrix <- xgb.importance(feature_names=colnames(x), model=xgb_tr)
importance_matrix$Varname = sapply(strsplit(importance_matrix$Feature, "\\."), `[[`, 1)
ImpMax = data.table(importance_matrix)
VarImp = ImpMax[, .(SGain=sum(Gain),SCover=sum(Cover),SFrequency=sum(Frequency)), by=Varname]
VarImp = VarImp[order(-VarImp$SGain),]
#View(VarImp)
mvar.vec = VarImp$Varname


Y18 = inf.df[inf.df$QTE_QUOTE_EFF_YEAR%in%2018,]
Y18$Pred = y.pred; Y18 = Y18[order(DRV_DRIVER_KEY),]

Y18[,clean_ind:=as.numeric(Y==0)]; Y18[,clean_pro:=(1-Pred)]
Y18 = Y18[order(-clean_pro),]
popu = round(5/100*dim(Y18)[1])
mean(Y18$clean_ind[1:popu])


fun_xgboost_to_sql(xgb_tr, output_file_name="mvr_mod_score.txt", input_table_name="MVR_FINAL_V_MODREADY","DRIVER_KEY")
