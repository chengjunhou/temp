library(data.table)
library(dplyr)
library(pmut)

Y18=fread('meta/Y18_Pred.csv')
Y18[,clean_ind:=as.numeric(Y==0)]; Y18[,clean_pro:=(1-Pred)]

targetstring="clean_ind"
rankstring="clean_pro"
pseq=c(0, 0.05, (1:8)*0.1)
data = Y18[Y18$QTE_STATE=='WI']
View(fun_mod_ptile(data, targetstring, rankstring, pseq, cumulative=TRUE))

targetstring="VALMVR_CNT"
rankstring="clean_pro"
pseq=c(0, 0.05, (1:10)*0.1)
data = Y18[Y18$QTE_STATE=='WI']
out = data.frame(fun_mod_ptile(data, targetstring, rankstring, pseq, cumulative=FALSE))
if (any(paste0('VALMVR_CNT.',c(1:13,15,26))%in%colnames(out))) {
  out[,paste0('VALMVR_CNT.',c(1:13,15,26))[!paste0('VALMVR_CNT.',c(1:13,15,26))%in%colnames(out)]] = 0
}
out = rbind(out, out[11,]); out[12,'LAB']='0 - 1'; out[12,colnames(out)[-1]]=colSums(out[1:11,2:17])
out$AVGCNT = (out$VALMVR_CNT.1*1 + out$VALMVR_CNT.2*2 + out$VALMVR_CNT.3*3 + out$VALMVR_CNT.4*4 + out$VALMVR_CNT.5*5 +
                out$VALMVR_CNT.6*6 + out$VALMVR_CNT.7*7 + out$VALMVR_CNT.8*8 + out$VALMVR_CNT.9*9 + out$VALMVR_CNT.10*10 + 
                out$VALMVR_CNT.11*11 + out$VALMVR_CNT.12*12 + out$VALMVR_CNT.13*13 + out$VALMVR_CNT.15*15 + out$VALMVR_CNT.26*26)/
             (out$VALMVR_CNT.1 + out$VALMVR_CNT.2 + out$VALMVR_CNT.3 + out$VALMVR_CNT.4 + out$VALMVR_CNT.5 +
                out$VALMVR_CNT.6 + out$VALMVR_CNT.7 + out$VALMVR_CNT.8 + out$VALMVR_CNT.9 + out$VALMVR_CNT.10 + 
                out$VALMVR_CNT.11 + out$VALMVR_CNT.12 + out$VALMVR_CNT.13 + out$VALMVR_CNT.15 + out$VALMVR_CNT.26)
oot = data.frame(out$LAB, out$VALMVR_CNT.0, out$VALMVR_CNT.1, out$VALMVR_CNT.2, out$VALMVR_CNT.3, out$VALMVR_CNT.4, out$VALMVR_CNT.5,
                 fff=out$VALMVR_CNT.6+out$VALMVR_CNT.7+out$VALMVR_CNT.8+out$VALMVR_CNT.9+out$VALMVR_CNT.10,
                 ttt=out$VALMVR_CNT.11+out$VALMVR_CNT.12+out$VALMVR_CNT.13+out$VALMVR_CNT.15+out$VALMVR_CNT.26,out$AVGCNT)
View(oot)


fun_mod_ptile <- function(data, targetstring, rankstring, pseq=c(0, 0.1, 0.2, 0.3, 0.4, 0.5), cumulative=TRUE) {
  data = data[order(-data[[rankstring]]),]
  data$LAB = NA_character_
  index.df = data.frame(SEQ=seq(1,length(pseq)-1), index.sta=NA, index.fin=NA)
  
  if (cumulative==TRUE) {
    index.df$index.sta = 1
    index.df$index.fin = round(pseq[-1]*dim(data)[1])
    index.df$LAB = paste0("0 - ", pseq[-1])
  } else {
    index.df$index.sta = round(pseq[-length(pseq)]*dim(data)[1]) + 1
    index.df$index.sta[1] = 1
    index.df$index.fin = round(pseq[-1]*dim(data)[1])
    index.df$LAB = paste0(pseq[-length(pseq)], " - ", pseq[-1])
  }
  
  for (i in 1:dim(index.df)[1]) {
    data$LAB[index.df$index.sta[i] : index.df$index.fin[i]] = index.df$LAB[i]
    zata = data[!is.na(LAB),]
    temp = unique(data[,get(targetstring)])[!unique(data[,get(targetstring)]) %in% unique(zata[,get(targetstring)])]
    if (length(temp)>0) {
    # this if part handles some percentiles do not have all elements
      for (j in 1:length(temp)) {
        zata = rbind(zata, data[get(targetstring)==temp[j],][1,])
        print(i)
        print(temp[j])
        zata$LAB = index.df$LAB[i]
      }
    }
    out.df = zata[, .N, by=.(LAB,get(targetstring))] %>% dcast(LAB ~ get, value.var='N')
    if (length(temp)>0) {
    # need to minus 1
      for (j in 1:length(temp)) {
        out.df[[as.character(temp[j])]][1] = out.df[[as.character(temp[j])]][1] - 1
      }
    }
    nlvl = dim(out.df)[2]
    names(out.df)[2:nlvl] = paste0(targetstring, ".", names(out.df)[2:nlvl])
    #out.df[,paste0(names(out.df)[2:nlvl],"%"):= out.df[,2:nlvl]/rowSums(out.df[,2:nlvl])] 
    if (i==1) {
      out = out.df
    } else {
      out = rbind(out, out.df)
    }
    data$LAB = NA_character_
  }
  
  #View(out)
  return(out)
}


