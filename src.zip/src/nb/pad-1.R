
View(dt[res.df$DRV_EVENT_VALMVR_ADMIN_MESSAGE_CNT==res.df$DRV_EVENT_VALMVR_CNT&res.df$DRV_EVENT_VALMVR_CNT>0, 
        .(QTE_QUOTE_POLICY_NUM,QTE_QUOTE_EFF_DTTM,QTE_INSURED_NAME,DRV_DRIVER_NAME,DRV_PQUOTE_CREDIT_SCORE)])


meta = data.frame(class.vec)
meta$Col = rownames(meta)
meta$Nuniq = sapply(dt, function(x) length(unique(x)))[1:length(class.vec)]
meta$Class = meta$class.vec
meta = meta[,c(2,4,3)]
rownames(meta) = seq(1,dim(meta)[1])
meta$Pmis = pmut.data.pmis(dt)[1:length(class.vec)]
#write.csv(meta, "meta/mvr-full-sta.csv")




### test xgb prediction mechanism ###
### proof only features in VarImp are used for scoring ###
temp.vec = xgb_tr$feature_names[!xgb_tr$feature_names%in%colnames(x.oo)]
temp = matrix(0, nrow=dim(x.oo)[1], ncol=length(temp.vec))
colnames(temp) = temp.vec
temp = cbind(x.oo, temp)
table(colnames(temp)[order(colnames(temp))]==colnames(x.zz)[order(colnames(x.zz))])
temp = temp[,order(colnames(temp))]
y.temp = predict(xgb_tr, temp)




index = which(dt$DRV_EVENT_EMP_CLASS_CTAB_MAJS>0)
View(dt[index,.(QTE_QUOTE_POLICY_NUM,
           QTE_QUOTE_NUM,
           QTE_QUOTE_EFF_DTTM,
           QTE_QUOTE_EFF_YEAR,
           QTE_QUOTE_EFF_MONTH,
           QTE_INSURED_NAME,
           DRV_DRIVER_NAME)])



