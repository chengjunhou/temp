
zxc = as.data.frame(table(dt$DRV_DRIVER_OCCUPATION))
head(zxc)
zxc = zxc[order(-zxc$Freq),]
zxc$Prop = zxc$Freq/sum(zxc$Freq)*100

zxc = as.data.frame(table(dt$QTE_PREV_CARRIER))
head(zxc)
zxc = zxc[order(-zxc$Freq),]
zxc$Prop = zxc$Freq/sum(zxc$Freq)*100


pmut.edap(dt[QTE_PREV_CARRIER%in%zxc$Var1[1:43],], 'QTE_PREV_CARRIER', 'RES')
pmut.edap(dt[QTE_PREV_CARRIER%in%zxc$Var1[44:104],], 'QTE_PREV_CARRIER', 'RES')
View(zxc)


###### drv-event NA
i1 = which(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT>0)
i2 = which(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT==dt$DRV_EVENT_CLUE_CLASS_CTAB_ALLO &
           dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT>0)
i3 = which(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT>0 &
             dt$DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT>=dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT)
# conclusion: unless i3, drv-event-NA should be dirty
View(cbind(inf.df[QTE_QUOTE_POLICY_NUM=='F  5277519',],
           dt[QTE_QUOTE_POLICY_NUM=='F  5277519',  .(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT)]))
View(cbind(inf.df[QTE_QUOTE_POLICY_NUM=='0739376000',],
           dt[QTE_QUOTE_POLICY_NUM=='0739376000',  .(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT)]))
View(cbind(inf.df[QTE_QUOTE_POLICY_NUM=='F  5285392',],
           dt[QTE_QUOTE_POLICY_NUM=='F  5285392',  .(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT)]))
View(cbind(inf.df[QTE_QUOTE_POLICY_NUM=='0706009900',],
           dt[QTE_QUOTE_POLICY_NUM=='0706009900',  .(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT)]))
View(cbind(inf.df[QTE_QUOTE_POLICY_NUM=='0763566800',],
           dt[QTE_QUOTE_POLICY_NUM=='0763566800',  .(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                                                     DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT)]))


index = which(dt$DRV_EVENT_CLUE_CLASS_CTAB_DUI>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT>0 &
                dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT==0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT==0)
View(inf.df[index,])
index = which(dt$DRV_EVENT_CLUE_CLASS_CTAB_MAJV>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT>0)
index1 = which(dt$DRV_EVENT_CLUE_CLASS_CTAB_MAJV>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT>0 &
                dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT==0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT==0)
View(inf.df[index1,])

View(dt[inf.df$QTE_QUOTE_POLICY_NUM=='F  5279543',.(DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                    DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT,
                                                    DRV_EVENT_CLUE_CLASS_CTAB_DUI)])


index = which(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT>0 & dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT>0 &
          dt$DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT==(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT+dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT))
View(inf.df[index,])

View(dt[inf.df$QTE_QUOTE_NUM=='478398400',.(DRV_DRIVER_NAME,DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                                    DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT,
                                                    DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT,DRV_EVENT_CLUE_CLASS_CTAB_ATA_BT)])

index1 = which()
View(ot[QTE_QUOTE_POLICY_NUM=='F  5280346',.(DRV_DRIVER_NAME,DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,
                                                    DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                                            DRV_EVENT_DRIVER_EVENT_ADDED_BY_AGENT_CNT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_EMP_CNT,
                                            DRV_EVENT_CLUE_CLASS_CTAB_ATA_AT,DRV_EVENT_CLUE_CLASS_CTAB_ATA_BT,
                                            DRV_EVENT_CLUE_CLASS_CTAB_NAF_AT,DRV_EVENT_CLUE_CLASS_CTAB_NAF_BT)])


index = which(dt$DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT==dt$DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT & 
                dt$DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT>0)
View(dt[index, .(QTE_QUOTE_POLICY_NUM,
                 QTE_QUOTE_NUM,
                 QTE_QUOTE_EFF_DTTM,
                 QTE_QUOTE_EFF_YEAR,
                 QTE_QUOTE_EFF_MONTH,
                 QTE_INSURED_NAME,
                 DRV_DRIVER_NAME,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_CLUE_CNT,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
                 DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
                 DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT,
                 DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
                 DRV_EVENT_CHARGE_TYPE_CD_CONCAT)])

