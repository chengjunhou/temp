temp = as.data.frame(table(dt$QTE_PREV_CARRIER))

temp = temp[order(-temp$Freq),]

dt[, QTE_PREV_CARRIER_bin:='OTHER']
dt[QTE_PREV_CARRIER%in%temp$Var1[1:23], QTE_PREV_CARRIER_bin:=QTE_PREV_CARRIER]

dt[QTE_PREV_CARRIER%in%c(
  'Commerce',
  'Penn National Insurance'
), QTE_PREV_CARRIER_bin:='g-p9']

dt[QTE_PREV_CARRIER%in%c(
  'USAA',
  'Donegal Group'
), QTE_PREV_CARRIER_bin:='g-p8']

dt[QTE_PREV_CARRIER%in%c(
  'West Bend Mutual Group',
  'Tennessee Farmers Mutual Insurance',
  'AAA (Personal Lines)',
  'Unitrin Inc'
), QTE_PREV_CARRIER_bin:='g-p7p6p5']

dt[QTE_PREV_CARRIER%in%c(
  'New Jersey Manufacturers Group',
  'Harleysville Insurance',
  'White Mountains Insurance Group',
  'Peerless'
), QTE_PREV_CARRIER_bin:='g-p4']

dt[QTE_PREV_CARRIER%in%c(
  'FARM BUREAU',
  'Pekin Insurance Group',
  'EMC Insurance Companies',
  'Ohio Mutual Insurance Group',
  'Western National Mutual Group',
  'Amica Mutual'
), QTE_PREV_CARRIER_bin:='g-p3']

dt[QTE_PREV_CARRIER%in%temp$Var1[42:53], QTE_PREV_CARRIER_bin:='g-p2']

dt[QTE_PREV_CARRIER%in%temp$Var1[54:65], QTE_PREV_CARRIER_bin:='g-p1']

dt[QTE_PREV_CARRIER%in%temp$Var1[66:104], QTE_PREV_CARRIER_bin:='g-p0']




