library(data.table)

meta <- fread("raw/mvr-full-meta.csv")

meta[, HEAD:=substr(QTE_QUOTE_POLICY_NUM,1,1)]
table(meta$HEAD)/dim(meta)[1]   # 30% issued

meta[, KEY:=paste(QTE_INSURED_NAME, QTE_INSURED_PHONE, sprintf("%09d",QTE_MAILING_ADDRESS_ZIP), DRV_DRIVER_NAME)]
key1.df = meta[, .N, by=KEY][order(-N),]
table(key1.df$N)
View(meta[KEY==key1.df[N==5,KEY][3],])

table(meta$DRV_PQUOTE_DRIVER_INELIGIBLE_DRIVER_IND)
table(meta$DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD)



qte <- fread("raw/qte-meta.csv")

qte[, HEAD:=substr(QUOTE_POLICY_NUM,1,1)]
table(qte$HEAD)/dim(qte)[1]   # 32% issued

qte[, KEY:=paste(INSURED_NAME, INSURED_PHONE, sprintf("%09d",MAILING_ADDRESS_ZIP))]
key1.df = qte[, .(.N,YearN=length(unique(QUOTE_EFF_YEAR)),YearMax=max(QUOTE_EFF_YEAR)), by=KEY][order(-N,-YearN,-YearMax),]
table(key1.df$N)
table(key1.df$YearN[key1.df$N==4])
table(key1.df$YearN[key1.df$N==3])
table(key1.df$YearN[key1.df$N==2])
View(qte[KEY==key1.df[N==2&YearN==2,KEY][1],])

qte[, KEY2:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP))]
length(unique(qte$KEY))
length(unique(qte$KEY2))
key2.df = qte[, .(.N,YearN=length(unique(QUOTE_EFF_YEAR)),YearMax=max(QUOTE_EFF_YEAR),PhoneN=length(unique(INSURED_PHONE))), 
              by=KEY2][order(-N,-PhoneN,-YearN,-YearMax),]
View(key2.df[PhoneN>1&YearMax>2016,])
qte[KEY2=='DONALD*DRAMSTAD 222012561',
    .(QUOTE_KEY,QUOTE_NUM,QUOTE_POLICY_NUM,QUOTE_EFF_DTTM,QUOTE_RECEIVED_DTTM,INSURED_PHONE,
      MAILING_ADDRESS_LINE_1,MAILING_ADDRESS_CITY,MAILING_ADDRESS_STATE_ABBREV)][order(QUOTE_RECEIVED_DTTM),]
meta[QTE_QUOTE_KEY==2953028,.(QTE_QUOTE_KEY,DRV_DRIVER_NAME,DRV_DRIVER_GENDER,DRV_PQUOTE_DRIVER_INELIGIBLE_DRIVER_IND,
                          DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD,DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
                          DRV_EVENT_CHARGE_TYPE_CD_CONCAT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT)]








