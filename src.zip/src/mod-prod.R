library(data.table)
library(ggplot2)
library(pmut)
source('src/xgb2sql/onehot-script.R')
source('src/xgb2sql/script.R')


class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)
qte = fread("raw/qte-meta.csv")


###### quote-num filter ######
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:2)]

dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt[,KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR, DRV_DRIVER_NAME)]

dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]
dt <- dt[order(QTE_QUOTE_POLICY_NUM, QTE_QUOTE_EFF_DTTM),]
source('src/data-prep.R')


###### response re-make ######
inf.df = dt[,.(QTE_QUOTE_KEY,
               QTE_QUOTE_POLICY_NUM,
               QTE_QUOTE_NUM,
               QTE_QUOTE_EFF_DTTM,
               QTE_QUOTE_EFF_YEAR,
               QTE_QUOTE_EFF_MONTH,
               QTE_INSURED_NAME,
               DRV_DRIVER_NAME)]
res.df = dt[,.(DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT,
               DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT,
               DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT,
               DRV_DRIVER_SDIP_PTS_NUM,
               DRV_DRIVER_ACCIDENT_CONVICTION_FREE_CD,
               DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,
               DRV_EVENT_CHARGE_TYPE_CD_CONCAT,
               DRV_EVENT_NUM_OF_POINTS_CONCAT,
               DRV_EVENT_MVR_POINTS_MAX)]

res.df[, Y:=0]
res.df[DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT>0, Y:=1]
res.df[DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT==0 & DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT>0 & 
         DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT<DRV_EVENT_DRIVER_EVENT_ADDED_BY_NA_CNT, Y:=1]
inf.df[,Y:=res.df$Y]


###### one-hot encode ######
source('src/vec-1.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]
#apply(dt[,catg.vec,with=F], 2, function(x) sum(is.na(x)))
#apply(dt[,catg.vec,with=F], 2, function(x) sum(x==''))
#table(catg.vec %in% mvar.vec)

#mvar.vec = readRDS('meta/mvar.vec')
#temp = dt[, mvar.vec, with=F]
#source('src/vec-easi.R')
#num.vec = c(num.vec, easi.vec[1:4])
#temp = dt[, c(catg.vec,num.vec), with=F]

mvar.vec = readRDS('meta/mvar.vec')
temp = dt[, mvar.vec, with=F]

#out <- fun_data_prep(temp, output_file_name='onehot.txt')
out <- fun_data_prep(temp)
rm(temp)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = out$model.matrix[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = out$model.matrix[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)



library(xgboost)
xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.29,                               # learning rate
  max.depth =  9,                           # max tree depth
  gamma = 15,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)

start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 48,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)

# optimal one obtained at iteration 37
importance_matrix <- xgb.importance(feature_names=colnames(x), model=xgb_tr)
importance_matrix$Varname = sapply(strsplit(importance_matrix$Feature, "\\."), `[[`, 1)
ImpMax = data.table(importance_matrix)
VarImp = ImpMax[, .(SGain=sum(Gain),SCover=sum(Cover),SFrequency=sum(Frequency)), by=Varname]
VarImp = VarImp[order(-VarImp$SGain),]
#View(VarImp)

Y18 = inf.df[inf.df$QTE_QUOTE_EFF_YEAR%in%2018,]
Y18$Pred = y.pred; Y18 = Y18[order(DRV_DRIVER_KEY),]

fun_xgboost_to_sql(xgb_tr, output_file_name="mvr_mod_score.txt", input_table_name="MVR_FINAL_V_MODREADY","DRV_DRIVER_KEY")

