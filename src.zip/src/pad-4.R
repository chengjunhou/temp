
tmp = dt[,.(QTE_QUOTE_POLICY_NUM,QTE_QUOTE_EFF_DTTM,QTE_QUOTE_EFF_YEAR,DRV_DRIVER_NAME,
            DRV_PQUOTE_CREDIT_SCORE,DRV_CREDIT_SCORE_STG,DRV_PQUOTE_INSURED_SPOUSAL_IND,
            DRV_PQUOTE_INSURED_TYPE_CD,CREDIT_SCORE,SPOUSE_CREDIT_SCORE,CREDIT_SCORE_INS)]

tmp[!is.na(DRV_CREDIT_SCORE_STG),][66000:66010,]



xgb_allvar = readRDS('meta/xgb_allvar')

y.pred = predict(xgb_allvar, x.oo)
y.pred = predict(xgb_tr, x.oo)


pred.df = data.frame(pro=y.pred, dirty=y.oo, clean=as.numeric(y.oo==0))
pred.df = pred.df[order(pred.df$pro),]
ppp = 5
table(pred.df$clean[1:round(ppp/100*dim(pred.df)[1])])/sum(table(pred.df$clean[1:round(ppp/100*dim(pred.df)[1])]))


# better dirty auc, better clean performance


