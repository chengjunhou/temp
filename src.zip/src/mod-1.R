################################
# Initial Train/Test Selection #
################################
library(xgboost)



xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.30,                               # learning rate
  max.depth =  6,                           # max tree depth
  gamma = 10,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)



###### xgb.cv ######
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016),]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016)]

start.time = Sys.time()
xgb_cv = xgb.cv(data = x, label = y,
                params = xgb_params_1,
                nrounds = 35, 
                early_stopping_rounds = 12,
                nthread = 8,
                nfold = 5,            # number of folds in K-fold
                showsd = TRUE,        # standard deviation of loss across folds
                stratified = TRUE,    # sample is unbalanced; use stratified sampling
                verbose = TRUE,
                print_every_n = 1
)
Sys.time() - start.time


###### xgb.tr ######
year.vec = c(2017,2018)
temp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%year.vec & inf.df$Y==0)
set.seed(91); temp1 = sample(temp, size=length(temp)*0.7); temp2 = temp[!temp%in%temp1];
temp1 = temp1[order(temp1)]; temp2 = temp2[order(temp2)]
zemp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%year.vec & inf.df$Y==1)
set.seed(92); zemp1 = sample(zemp, size=length(zemp)*0.7); zemp2 = zemp[!zemp%in%zemp1];
zemp1 = zemp1[order(zemp1)]; zemp2 = zemp2[order(zemp2)]
x = rbind(MATA[temp1,], MATA[zemp1,])
y = c(inf.df$Y[temp1], inf.df$Y[zemp1])
x.oo = rbind(MATA[temp2,], MATA[zemp2,])
y.oo = c(inf.df$Y[temp2], inf.df$Y[zemp2])
rm(temp,temp1,temp2,zemp,zemp1,zemp2,year.vec)

start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 35,                # max number of trees to build
                 early_stopping_rounds = 12,  # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)


tyear.vec = c(2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)

start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 35,                # max number of trees to build
                 early_stopping_rounds = 12,  # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)
