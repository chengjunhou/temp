kkk = Y18$DRV_DRIVER_KEY[index]

mvr = sqlQuery(con, "select * from SANDBOX_CJ.dbo.MVR_FINAL_V_MODREADY
                      where DRV_DRIVER_KEY in (31141,67504,223138,3994288,4477102,
                      5089997,6251343,6649426,6657984,6677887);", stringsAsFactors=F)
mvr = as.matrix(mvr)
mvr = mvr[order(mvr[,1]),]
mvr = mvr[,order(colnames(mvr))]

mod = out$model.matrix[inf.df$DRV_DRIVER_KEY%in%kkk,]
mod = cbind(mod, inf.df$DRV_DRIVER_KEY[inf.df$DRV_DRIVER_KEY%in%kkk])
colnames(mod)[229] = 'DRV_DRIVER_KEY'
mod = mod[,-1]
mod = mod[order(mod[,228]),]
mod = mod[,order(colnames(mod))]

bool.vec = rep(FALSE, 228)
for (i in 1:228) {
  bool.vec[i] = all(mvr[,i]==mod[,i])
}

dt[DRV_DRIVER_KEY%in%kkk,.(DRV_DRIVER_KEY,QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY,
     QTE_PRIOR_CARRIER_YEARS_CONTINOUS_LIABILITY_num)][order(DRV_DRIVER_KEY)]





yt = inf.df[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
yt$pred = predict(xgb_tr, x)
yt$key = paste(QTE_QUOTE_POLICY_NUM, QTE_QUOTE_EFF_YEAR, sep=' ')
yty = yt[, .(cnt=.N, avg_p=mean(pred), sd_p=sd(pred), max_p=max(pred), min_p=min(pred), diff_p=max(pred)-min(pred)), by=key]

ggplot(yty, aes(x = factor(cnt))) +  
  geom_bar(aes(y = (..count..)/sum(..count..))) + 
  scale_y_continuous(labels = scales::percent)

ggplot(yty[cnt>1,], aes(x = diff_p)) + geom_histogram(binwidth = 0.01) + xlim(0,1) +
  geom_vline(xintercept=mean(yty[cnt>1,diff_p]),color='red') + xlab("Diff between Max and Min Propensity within Same Quote")

ggplot(yty[cnt>1,], aes(x = sd_p)) + geom_histogram(binwidth = 0.01) + xlim(0,1) +
  geom_vline(xintercept=mean(yty[cnt>1,sd_p]),color='red') + xlab("Standard Deviation of Propensity within Same Quote")

ggplot(yty[cnt>1,], aes(x = diff_p)) + geom_density((aes(y = ..scaled..)))

ggplot(yt, aes(x = pred)) + geom_histogram(binwidth = 0.01)

