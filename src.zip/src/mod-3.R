################################
# More Feature One at Time #
################################

xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.29,                               # learning rate
  max.depth =  9,                           # max tree depth
  gamma = 15,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)


source('src/vec-1.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]

#catg.vec = c(catg.vec, 'QTE_PREV_CARRIER_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_OCCUPATION_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_LICENSE_STATE')
#num.vec = c(num.vec, 'QTE_TOTAL_PREMIUM')
#num.vec = c(num.vec, c('VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG'))


temp = dt[,catg.vec,with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(dt[,num.vec,with=F]))
#temp = readRDS('meta/data-make.rds')
#colnames(temp) = paste0('VEH_Vehicle_Make_CTAB...', colnames(temp))
#MATA = cbind(MATA, temp)
rm(temp)


tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 39,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)


###### importance matrix ######
importance_matrix <- xgb.importance(feature_names=colnames(x), model=xgb_tr)
importance_matrix$Varname = sapply(strsplit(importance_matrix$Feature, "\\.\\.\\."), `[[`, 1)
ImpMax = data.table(importance_matrix)
VarImp = ImpMax[, .(SGain=sum(Gain),SCover=sum(Cover),SFrequency=sum(Frequency)), by=Varname]
VarImp = VarImp[order(-VarImp$SGain),]
View(VarImp)

VarImp$o1 = order(-VarImp$SGain)
VarImp$o2 = order(-VarImp$SCover)
VarImp$o3 = order(-VarImp$SFrequency)
VarImp$od = VarImp$o1 + VarImp$o2 + VarImp$o3


###### subset var retain top predictors ######
mvar.vec = VarImp$Varname[VarImp$SCover>1e-04]
mvar.vec = VarImp$Varname[VarImp$SFrequency>0.001]
mvar.vec = VarImp$Varname

temp = dt[,catg.vec[catg.vec%in%mvar.vec],with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(dt[,num.vec[num.vec%in%mvar.vec],with=F]))
rm(temp)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 48,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)







pred.df = data.frame(pro=y.pred, dirty=y.oo, clean=as.numeric(y.oo==0))
pred.df = pred.df[order(pred.df$pro),]

pred.df$cpro = 1- pred.df$pro
ggplot(pred.df, aes(x=cpro)) + geom_histogram(aes(y = (..count..)/sum(..count..)), binwidth=0.05) + 
  scale_y_continuous(labels=scales::percent) + xlab('Clean Propensity Distribution') + ylab('Count Percentage') +
  geom_vline(xintercept=median(zxc), color='#E41A1C')

popu = round(5/100*dim(pred.df)[1])
table(pred.df$dirty[1:popu])



