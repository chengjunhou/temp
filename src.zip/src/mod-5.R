################################
# EASI and Some Others #
################################
library(xgboost)

class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)
ot = ot[order(QTE_MVR_QUOTE_KEY,DRV_DRIVER_KEY), ]
qte = fread("raw/qte-meta.csv")
temp = fread("raw/1020/mvr-full.csv")
temp = temp[order(QTE_MVR_QUOTE_KEY,DRV_DRIVER_KEY), ]
ot[, DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT:=temp$DRV_EVENT_DRIVER_EVENT_ADMIN_MESSAGE_CNT]
rm(temp)

###### quote-num filter ######
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:2)]
dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt[,KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR, DRV_DRIVER_NAME)]

###### process data ######
dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]
dt <- dt[order(QTE_QUOTE_POLICY_NUM, QTE_QUOTE_EFF_DTTM),]
source('src/data-prep.R')


xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.29,                               # learning rate
  max.depth =  9,                           # max tree depth
  gamma = 15,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)


source('src/vec-1.R')
source('src/vec-easi.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]

#catg.vec = c(catg.vec, 'QTE_PREV_CARRIER_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_OCCUPATION_bin')
#catg.vec = c(catg.vec, 'DRV_DRIVER_LICENSE_STATE')
#num.vec = c(num.vec, 'QTE_TOTAL_PREMIUM')
#num.vec = c(num.vec, c('VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG'))
dt[Dominant_Profile=='',Dominant_Profile:='MED_INC']
catg.vec = c(catg.vec, 'Dominant_Profile')
num.vec = c(num.vec, easi.vec[easi.vec!='Dominant_Profile'])




############################################################
class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)
qte = fread("raw/qte-meta.csv")
easi = fread("raw/mvr-easi.csv")

###### quote-num filter ######
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:2)]
dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]

source('src/data-prep.R')
temp = nchar(dt$QTE_MAILING_ADDRESS_ZIP)
dt[,ZIP:=QTE_MAILING_ADDRESS_ZIP]
dt[temp%in%c(8,9),ZIP:=as.integer(substr(sprintf("%09d",QTE_MAILING_ADDRESS_ZIP),1,5))]
dt <- merge(dt, easi, by.x='ZIP', by.y='ZIP_Code', all.x=TRUE)


source('src/vec-1.R')
catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]

source('src/vec-easi.R')
#num.vec = c(num.vec, easi.vec[1:4])


temp = dt[,catg.vec,with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(dt[,num.vec,with=F]))
rm(temp)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 39,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)



################################
# Two Steps #
################################
dt[, KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR)]
dt[, Y:=res.df$Y]
dt.unq = dt[,.(CNT=.N, DRV_DRIVER_KEY=max(DRV_DRIVER_KEY), YS=sum(Y)),by=KEY][order(KEY),]

catg.vec = catg.vec[!catg.vec%in%c('QTE_PREV_CARRIER_bin','DRV_DRIVER_OCCUPATION_bin','DRV_DRIVER_LICENSE_STATE')]
num.vec = num.vec[!num.vec%in%c('QTE_QUOTE_EFF_YEAR','QTE_TOTAL_PREMIUM',
                                'VEH_Vehicle_Prem_MAX','VEH_Vehicle_Prem_MIN','VEH_Vehicle_Prem_AVG')]

catg.aec = catg.vec[c(grep('QTE_',catg.vec),grep('COV_',catg.vec),grep('VEH_',catg.vec))]
num.aec = num.vec[c(grep('QTE_',num.vec),grep('COV_',num.vec),grep('VEH_',num.vec))]
at = dt[DRV_DRIVER_KEY%in%dt.unq$DRV_DRIVER_KEY, c(catg.aec,num.aec,'KEY','QTE_QUOTE_EFF_YEAR'), with=FALSE]
at = at[order(KEY),]
at[, Y:=as.numeric(dt.unq$YS>0)]


temp = at[,catg.aec,with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(at[,num.aec,with=F]))
rm(temp)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[at$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = at$Y[at$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[at$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = at$Y[at$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 34,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)


catg.bec = catg.vec[grep('DRV_',catg.vec)]
num.bec = num.vec[grep('DRV_',catg.vec)]
at[,PRO:=predict(xgb_tr, MATA)]
bt = dt[, c(catg.bec,num.bec,'KEY','QTE_QUOTE_EFF_YEAR','Y'), with=FALSE]
bt = merge(bt, at[,.(KEY,PRO)], by='KEY', all.x=TRUE)


temp = bt[,catg.bec,with=F]
names(temp) = paste0(names(temp), "...")
temp = model.matrix(~., temp)
MATA = cbind(temp, as.matrix(bt[,c(num.bec,'PRO'),with=F]))
rm(temp)

tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[bt$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = bt$Y[bt$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[bt$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = bt$Y[bt$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)


start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 39,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)



