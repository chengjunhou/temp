library(tm)

docs = Corpus(VectorSource(dt$VEH_Vehicle_Make_CONCAT))
inspect(docs)

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
docs <- tm_map(docs, toSpace, ",")
inspect(docs)

dtm <- DocumentTermMatrix(docs)
m <- as.matrix(dtm)

v <- sort(colSums(m),decreasing=TRUE)

d <- data.frame(word = names(v),freq=v,stringsAsFactors=FALSE)
head(d, 10)

#d$word[d$freq<1000]
other = rowSums(m[,d$word[d$freq<1000]])

#zxc = cbind(m[,c('ford','chev','jeep','audi','gmc','toyota','honda')], other)
zxc = cbind(m[,d$word[d$freq>=1000]], other)
saveRDS(zxc, 'meta/data-make.rds')

