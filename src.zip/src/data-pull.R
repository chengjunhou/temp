library(RODBC)
library(data.table)
con  <- odbcConnect("SOG_Sandbox", uid="houche1", pwd="FAFAll426")

mvr <- sqlQuery(con, "select * from SOG_ANALYTIC_APPS.dbo.MVR_FINAL_V", stringsAsFactors=F)
mvr <- sqlQuery(con, "select * from SOG_ANALYTIC_APPS.dbo.MVR_FINAL_V_CR_SCORE", stringsAsFactors=F)
mvr <- data.table(mvr)

mvr[,QTE_QUOTE_EFF_DTTM:=as.character(QTE_QUOTE_EFF_DTTM)]
mvr[,QTE_QUOTE_EXP_DTTM:=as.character(QTE_QUOTE_EXP_DTTM)]
mvr[,QTE_QUOTE_RECEIVED_DTTM:=as.character(QTE_QUOTE_RECEIVED_DTTM)]
mvr[,VEH_QUOTE_EFF_DT:=as.character(VEH_QUOTE_EFF_DT)]
mvr[,DRV_DRIVER_LICENSE_DTTM:=as.character(DRV_DRIVER_LICENSE_DTTM)]
mvr[,DRV_QUOTE_RECEIVED_DTTM:=as.character(DRV_QUOTE_RECEIVED_DTTM)]
class.vec = sapply(mvr, class)
table(class.vec)

fwrite(mvr, "raw/mvr-full.csv")
saveRDS(class.vec, "raw/mvr-full-class.rds")


meta <- mvr[,.(QTE_QUOTE_KEY,QTE_QUOTE_NUM,QTE_QUOTE_POLICY_NUM,
               QTE_INSURED_NAME,QTE_INSURED_PHONE,
               QTE_MAILING_ADDRESS_LINE_1,QTE_MAILING_ADDRESS_CITY,QTE_MAILING_ADDRESS_STATE_ABBREV,QTE_MAILING_ADDRESS_ZIP,
               QTE_QUOTE_EFF_YEAR,QTE_QUOTE_EFF_MONTH,QTE_QUOTE_EFF_DTTM,QTE_QUOTE_EXP_DTTM,QTE_QUOTE_RECEIVED_DTTM,
               VEH_Vehicle_Year_CONCAT,VEH_Vehicle_Make_CONCAT,VEH_Vehicle_Model_CONCAT,
               DRV_DRIVER_NAME,DRV_DRIVER_RATING_AGE,DRV_DRIVER_GENDER,
               DRV_PQUOTE_DRIVER_INELIGIBLE_DRIVER_IND,DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD,
               DRV_EVENT_ACCIDENT_VIOLATION_CONCAT,DRV_EVENT_CHARGE_TYPE_CD_CONCAT,DRV_EVENT_DRIVER_EVENT_ADDED_BY_MVR_CNT)]
fwrite(meta, "raw/mvr-full-meta.csv")


qte <- sqlQuery(con, "select QUOTE_KEY, QUOTE_NUM, QUOTE_POLICY_NUM, INSURED_NAME, INSURED_PHONE,
                MAILING_ADDRESS_LINE_1, MAILING_ADDRESS_CITY, MAILING_ADDRESS_STATE_ABBREV,
                MAILING_ADDRESS_ZIP, QUOTE_EFF_DTTM, QUOTE_EXP_DTTM, QUOTE_RECEIVED_DTTM,
                QUOTE_EFF_YEAR, QUOTE_EFF_MONTH
                from SOG_ANALYTIC_APPS.dbo.MVR_QUOTE", stringsAsFactors=F)
qte <- data.table(qte)
fwrite(qte, "raw/qte-meta.csv")





class.vec = readRDS("raw/mvr-full-class.rds")
ot = fread("raw/mvr-full.csv", colClasses=class.vec)
qte = fread("raw/qte-meta.csv")


###### quote-num filter ######
qte[, KEY:=paste(INSURED_NAME, sprintf("%09d",MAILING_ADDRESS_ZIP), QUOTE_EFF_YEAR)]
qte.unq = qte[, .(.N, QTE_NUM=max(QUOTE_NUM), EFF_YEAR=max(QUOTE_EFF_YEAR)), by=KEY][order(KEY,-N,-EFF_YEAR)]
qte.vec = qte.unq$QTE_NUM[-(1:2)]
dt <- ot[QTE_QUOTE_NUM%in%qte.vec,]
dt[,KEY:=paste(QTE_QUOTE_NUM, QTE_QUOTE_EFF_YEAR, DRV_DRIVER_NAME)]

###### process data ######
dt <- dt[!is.na(VEH_MVR_VEHICLE_KEY),]
dt <- dt[QTE_QUOTE_TERM_IN_MONTHS==12,]
dt <- dt[DRV_PQUOTE_DRIVER_MVR_ORDER_THRU_CD=='O',]
dt <- dt[order(QTE_QUOTE_POLICY_NUM, QTE_QUOTE_EFF_DTTM),]


###### create meta ######
meta = data.frame(class.vec)
meta$Col = rownames(meta)
meta$Nuniq = sapply(dt, function(x) length(unique(x)))[1:length(class.vec)]
meta$Class = meta$class.vec
meta = meta[,c(2,4,3)]
rownames(meta) = seq(1,dim(meta)[1])
meta$Pmis = pmut.data.pmis(dt)[1:length(class.vec)]
#write.csv(meta, "meta/mvr-full-sta.csv")

