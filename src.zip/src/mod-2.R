################################
# Fix Werid Find; Hyper Tune #
################################


temp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==0)
set.seed(91); temp1 = sample(temp, size=length(temp)*0.7); temp2 = temp[!temp%in%temp1];
temp1 = temp1[order(temp1)]; temp2 = temp2[order(temp2)]
zemp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==1)
set.seed(92); zemp1 = sample(zemp, size=length(zemp)*0.7); zemp2 = zemp[!zemp%in%zemp1];
zemp1 = zemp1[order(zemp1)]; zemp2 = zemp2[order(zemp2)]
x = rbind(MATA[temp1,], MATA[zemp1,])
y = c(inf.df$Y[temp1], inf.df$Y[zemp1])
x.oo = rbind(MATA[temp2,], MATA[zemp2,])
y.oo = c(inf.df$Y[temp2], inf.df$Y[zemp2])
rm(temp,temp1,temp2,zemp,zemp1,zemp2)


temp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==0)
set.seed(81); temp1 = sample(temp, size=length(temp)*0.7); temp2 = temp[!temp%in%temp1];
temp1 = temp1[order(temp1)]; temp2 = temp2[order(temp2)]
zemp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==1)
set.seed(82); zemp1 = sample(zemp, size=length(zemp)*0.7); zemp2 = zemp[!zemp%in%zemp1];
zemp1 = zemp1[order(zemp1)]; zemp2 = zemp2[order(zemp2)]
x = rbind(MATA[temp1,], MATA[zemp1,])
y = c(inf.df$Y[temp1], inf.df$Y[zemp1])
x.oo = rbind(MATA[temp2,], MATA[zemp2,])
y.oo = c(inf.df$Y[temp2], inf.df$Y[zemp2])
rm(temp,temp1,temp2,zemp,zemp1,zemp2)


temp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==0)
set.seed(81); temp1 = sample(temp, size=length(temp)*0.7); temp2 = temp[!temp%in%temp1];
temp1 = temp1[order(temp1)]; temp2 = temp2[order(temp2)]
zemp = which(inf.df$QTE_QUOTE_EFF_YEAR%in%c(2016,2017,2018) & inf.df$Y==1)
set.seed(82); zemp1 = sample(zemp, size=length(zemp)*0.7); zemp2 = zemp[!zemp%in%zemp1];
zemp1 = zemp1[order(zemp1)]; zemp2 = zemp2[order(zemp2)]
x = rbind(MATA[temp1,], MATA[zemp1,])
y = c(inf.df$Y[temp1], inf.df$Y[zemp1])
x.oo = rbind(MATA[temp2,], MATA[zemp2,])
y.oo = c(inf.df$Y[temp2], inf.df$Y[zemp2])
rm(temp,temp1,temp2,zemp,zemp1,zemp2)


x = rbind(MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==0,], 
          MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==1,])
y = c(inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==0], 
      inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==1])
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2018),]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2018)]
x.oo = rbind(MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==1,], 
             MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==0,])
y.oo = c(inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2014,2015,2016) & inf.df$Y==1], 
         inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%c(2015,2016,2017) & inf.df$Y==0])



###### hyper tune ######
tyear.vec = c(2014,2015,2016,2017)
oyear.vec = c(2018)
x = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec,]
y = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%tyear.vec]
x.oo = MATA[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec,]
y.oo = inf.df$Y[inf.df$QTE_QUOTE_EFF_YEAR%in%oyear.vec]
rm(tyear.vec, oyear.vec)

search.df = expand.grid(treedepth=c(6,8,10),learnrate=c(0.1,0.2,0.3,0.4,0.5),gamma=c(5,10,15))
search.df = expand.grid(treedepth=c(10,11,12),learnrate=c(0.26,0.28,0.30,0.32,0.34),gamma=c(15,20))
search.df = expand.grid(treedepth=c(9,10,11),learnrate=c(0.29,0.30,0.31),gamma=c(15))
search.df$iter = NA; search.df$train_auc = NA; search.df$test_auc = NA
detail.list = list()

for (i in 1:dim(search.df)[1]) {
  print(i)
  xgb_params_1 = list(
    objective = "binary:logistic",            # binary classification
    eta = search.df$learnrate[i],             # learning rate
    max.depth =  search.df$treedepth[i],      # max tree depth
    gamma = search.df$gamma[i],
    eval_metric = "auc"                       # evaluation/loss metric
  )
  
  xgb_tr = xgboost(data = x, label = y,
                   params = xgb_params_1,
                   nrounds = 35,                # max number of trees to build
                   early_stopping_rounds = 12,  # stop if no improvement within 12 trees
                   nthread = 8,
                   verbose = TRUE,                                         
                   print_every_n = 1
  )
  y.pred = predict(xgb_tr, x.oo)
  
  detail.list[[i]] = xgb_tr$evaluation_log
  search.df$iter[i] = xgb_tr$best_iteration
  search.df$train_auc[i] = xgb_tr$best_score
  search.df$test_auc[i] = pmut.auc(y.oo, y.pred, plot=FALSE)
  print(search.df$test_auc[i])
}

saveRDS(detail.list,"tmp/detail.list-1")
saveRDS(search.df, "tmp/search.df-1")

p <- ggplot(search.df, aes(x=as.factor(treedepth), y=as.factor(learnrate), fill=test_auc)) + 
  geom_tile(color="white") + scale_fill_gradient(low="white", high="steelblue")
p + facet_grid(.~gamma)



###### finalize ######
xgb_params_1 = list(
  objective = "binary:logistic",            # binary classification
  eta = 0.29,                               # learning rate
  max.depth =  9,                          # max tree depth
  gamma = 15,                               # regularization
  eval_metric = "auc"                       # evaluation/loss metric
)

start.time = Sys.time()
xgb_tr = xgboost(data = x, label = y,
                 params = xgb_params_1,
                 nrounds = 45,                # max number of trees to build
                 early_stopping_rounds = 6,   # stop if no improvement within 12 trees
                 nthread = 8,
                 verbose = TRUE,                                         
                 print_every_n = 1
)
Sys.time() - start.time
y.pred = predict(xgb_tr, x.oo)
pmut.auc(y.oo, y.pred, plot=FALSE)
