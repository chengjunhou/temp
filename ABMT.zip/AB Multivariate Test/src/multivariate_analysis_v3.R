library(shiny)



ui <- fluidPage(
  # App title ----
  headerPanel('Multivariate testing')
  ,
  sidebarPanel(
    fileInput('file1', 'Choose CSV File',
              accept=c('text/csv', 'text/comma-separated- values,text/plain', '.csv'))
    ,
    tags$hr(),
    checkboxInput('header', 'Header', TRUE),
    radioButtons('sep',  'Separator',
                 c(Comma=',',
                   Semicolon=';',
                   Tab='\t')),
    uiOutput("rest_var_select")
    
    
  ),
  
  mainPanel(
    
    
    verbatimTextOutput("model_summary"),
    
    # verbatimTextOutput("best_comb")
    tableOutput("best_comb"),
    verbatimTextOutput("predicted_ci")
  )
)

server <- function(input, output, session) {
  
  mydata <- reactive({
    
    inFile <- input$file1
    
    if (is.null(inFile))
      return(NULL)
    
    tbl <- read.csv(inFile$datapath, header=input$header, sep=input$sep,  dec = input$dec)
    
    return(tbl)
  })
  
  output$rest_var_select<-renderUI({
    factors_data <- ncol(mydata())-2
    covariates_choose <- names(mydata())[1:factors_data]
    checkboxGroupInput("other_var_select","Select other Var",choices =as.list(covariates_choose),selected=as.list(covariates_choose))
  })
  
  output$newdata <- renderText({
    x <- mydata()[,2]
    summary(x)
  })
  
  
  
  
  model_fit <- reactive({
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    input$other_var_select
    
    xmat<- mydata()[,input$other_var_select]
    open_y<- mydata()[,(factors_data+1)]
    y_c<-mydata()[,(factors_data+2)]-open_y
    if(length(input$other_var_select)>1)
    {
      
      data_matrix<- cbind(xmat,open_y,y_c)
      model_f<-glm(cbind(open_y,y_c)~.*.,data = data_matrix,family = binomial)
      return(model_f)
      
    }
    else
    {
      names(xmat)<- input$other_var_select
      model_f<- glm(cbind(open_y,y_c)~xmat,family = binomial)
    }
    
    
  })
  
  output$model_summary <- renderPrint({
    summary(model_fit())
    
  }
  
  )
  output$best_comb <- renderTable({
    
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    open_y<- mydata()[,(factors_data+1)]
    input$other_var_select
    
    xmat<- mydata()[,input$other_var_select]
    if(length(input$other_var_select)>1)
    {
      pred<- predict(model_fit(),xmat)
      max_index<- which.max(pred)
      xmat[max_index,]
    }
      
    else if(length(input$other_var_select)==1)
    {
      
      ag_data<-aggregate(open_y,by=list(Category=xmat),FUN=sum)
      
      # maxlevel<-table(ag_data[which.max(ag_data[,2]),1])
      ag_data
     
    }
    else
      return("NO DATASET")
    },
    
    caption = "Best combination of factors:",
    caption.placement = getOption("xtable.caption.placement", "top"), 
    caption.width = getOption("xtable.caption.width", NULL))
  
  
  
  output$predicted_ci <- renderPrint({
    
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    input$other_var_select
    
    xmat<- mydata()[,input$other_var_select]
    preds<- predict(model_fit(),xmat,type="link",se.fit=TRUE)
    # 
    max_index<- which.max(preds$fit)
    # 
  
    critval <- 1.96 ## approx 95% CI
    upr <- preds$fit + (critval * preds$se.fit)
    lwr <- preds$fit - (critval * preds$se.fit)
    
    upr2 <- model_fit()$family$linkinv(upr)[max_index]
    lwr2 <- model_fit()$family$linkinv(lwr)[max_index]
    #
    print(paste("95% Confidence interval of prediction for best combination of factors= ","(",lwr2,",",upr2,")"))
  })
  
}







shinyApp(ui, server)