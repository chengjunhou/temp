#Sample size calculation binomial response

a=2;
y = runif(eval(parse(text = paste("a",sep = ""))))
eval(parse(text = paste("y","<-","200",sep = "")))


a=c(0,1)
b=c(0,1)
c=c(0,1)
xmat = expand.grid(a=a,b=b,c=c)
xmat
y = c(200,250,265,347,210,286,271,326)
z = c(1000,1000,1000,1000,1000,1000,1000,1000)
xmat = cbind(y,z,xmat)
summary(glm(cbind(y,z-y)~ .^2,data = xmat,family = binomial))    




