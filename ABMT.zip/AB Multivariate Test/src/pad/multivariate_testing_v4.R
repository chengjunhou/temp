library(shiny)

#need to add ability to change interaction degree

ui <- fluidPage(
  # App title ----
  headerPanel('Multivariate testing')
  ,
  sidebarPanel(
    fileInput('file1', 'Choose CSV File',
              accept=c('text/csv', 'text/comma-separated- values,text/plain', '.csv'))
    ,
    tags$hr(),
    checkboxInput('header', 'Header', TRUE),
    radioButtons('sep',  'Separator',
                 c(Comma=',',
                   Semicolon=';',
                   Tab='\t')),
    uiOutput("rest_var_select")
    
    
  ),
  
  mainPanel(
    
    
    verbatimTextOutput("model_summary"),
    
    # verbatimTextOutput("best_comb")
    tableOutput("best_comb"),
    verbatimTextOutput("predicted_ci")
  )
)

server <- function(input, output, session) {
  
  
  mydata_orig <- reactive({
    #reads original dataset
    inFile <- input$file1
    
    if (is.null(inFile))
      return(NULL)
    
    tbl <- read.csv(inFile$datapath, header=input$header, sep=input$sep,  dec = input$dec)
    
    return(tbl)
  })
  
  
  mydata <- reactive({
    #Reads dataset from csv file and generates matrix with all combination of interactions  
    # inFile <- input$file1
    # 
    # if (is.null(inFile))
    #   return(NULL)
    # 
    # tbl <- read.csv(inFile$datapath, header=input$header, sep=input$sep,  dec = input$dec)
    tbl<- mydata_orig()
    
    factors_data <- ncol(tbl)-2
    assign("xmat_inter",eval(parse(text = paste("as.data.frame(model.matrix(~ .^",factors_data,"-1,tbl[,(1:factors_data)])) "))))
    # xmat_inter<- as.data.frame(model.matrix(~ .^2,tbl[,(1:factors_data)])) 
    tbl<-cbind(xmat_inter,tbl[,(factors_data+1):(factors_data+2)])
    return(tbl)
  })
  
  
  
  
  output$rest_var_select<-renderUI({
    factors_data <- ncol(mydata())-2
    covariates_choose <- names(mydata())[1:factors_data]
    checkboxGroupInput("other_var_select","Select other Var",choices =as.list(covariates_choose),selected=as.list(covariates_choose))
  })
  
  
  
  
  
  
  model_fit <- reactive({
    
    #this function fits a glm logistic model to the data
    
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    input$other_var_select
    
    xmat<- mydata()[,input$other_var_select]
    open_y<- mydata()[,(factors_data+1)]
    y_c<-mydata()[,(factors_data+2)]-open_y
    if(length(input$other_var_select)>1)
    {
      
      
      
      data_matrix<- cbind(xmat,open_y,y_c)
      
      # assign(paste("model_f"),eval(parse(text=paste("glm(cbind(open_y,y_c)~.^",jj,",data = data_matrix,family = binomial)",sep = ""))))
      model_f<-glm(cbind(open_y,y_c)~. ,data = data_matrix,family = binomial)
      return(model_f)
      
    }
    else
    {
      names(xmat)<- input$other_var_select
      model_f<- glm(cbind(open_y,y_c)~xmat,family = binomial)
    }
    
    
  })
  
  output$model_summary <- renderPrint({
    summary(model_fit())
    
  }
  
  )
  output$best_comb <- renderTable({
    
    #This function outputs the combination of levels with best predicted open rate
    
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    open_y<- mydata()[,(factors_data+1)]
    input$other_var_select
    
    
    
    
    
    xmat<- mydata()[,input$other_var_select]
    
    
    if(length(input$other_var_select)>1)
    {
      #find the row that gives max predicted open rate
      pred<- predict(model_fit(),xmat)
      max_index<- which.max(pred)
      
      #find the columns to display
      number_main <- ncol(mydata_orig())-2
      covariates_main <- names(mydata())[1:number_main]
      input_main_effects<- intersect(covariates_main,input$other_var_select)
      
      
      #display the combination with maximum open rate  
      xmat[max_index,input_main_effects]
    }
    
    else if(length(input$other_var_select)==1)
    {
      
      ag_data<-aggregate(open_y,by=list(Category=xmat),FUN=sum)
      
      ag_data
      
    }
    else
      return("NO DATASET")
  },
  
  caption = "Best combination of factors:",
  caption.placement = getOption("xtable.caption.placement", "top"), 
  caption.width = getOption("xtable.caption.width", NULL))
  
  
  
  output$predicted_ci <- renderPrint({
    
    all_data<-mydata()
    factors_data <- ncol(all_data)-2
    input$other_var_select
    
    xmat<- mydata()[,input$other_var_select]
    preds<- predict(model_fit(),xmat,type="link",se.fit=TRUE)
    # 
    max_index<- which.max(preds$fit)
    # 
    
    critval <- 1.96 ## approx 95% CI
    upr <- preds$fit + (critval * preds$se.fit)
    lwr <- preds$fit - (critval * preds$se.fit)
    
    upr2 <- model_fit()$family$linkinv(upr)[max_index]
    lwr2 <- model_fit()$family$linkinv(lwr)[max_index]
    #
    print(paste("95% Confidence interval of prediction for best combination of factors= ","(",lwr2,",",upr2,")"))
  })
  
}







shinyApp(ui, server)