library(shiny)



ui <- fluidPage(
  # App title ----
  headerPanel("Sample size calculator for 2^n full factorial design"),
  
  # Sidebar panel for inputs ----
  sidebarPanel(
    numericInput(inputId = "input_prop",label = "Expected email open rate",value=0.3,min = 0.1,max = 0.9,step = 0.1),
    numericInput(inputId = "input_delta",label = "Expected change in email open rate",value=0.1,min = 0.1,max = 0.9,step = 0.1),
    numericInput(inputId = "input_nfactors",label = "Number of factors",value=2,min = 1,max = 5,step = 1),
    numericInput(inputId = "input_alpha",label = "Significance level(alpha level)",value=0.05,min = 0.01,max = 0.2,step = 0.01),
    numericInput(inputId = "input_power",label = "Power (1-beta)",value=0.8,min = 0.2,max = 0.9,step = 0.1)
  ),
  
  mainPanel(
    textOutput("y",container = span)
  )
)

server <- function(input, output, session) {
  
  
  
  
  
  output$y<- renderPrint(paste("Sample size required in each group = ",output_function(input$input_prop,input$input_delta,input$input_nfactors,input$input_alpha,input$input_power)))
  
  output_function<- function(input_prop,input_delta,input_nfactors,input_alpha,input_power)
  {
    
    req_power = input_power    #Target power
    alpha_level = input_alpha  #significance level 
    
    n_factors <- input_nfactors #Number of factors
    
    n_levels <- 2 #Numbers of levels in each factor
    
    
    
    n_groups <- n_levels^n_factors #Number of cells
    
    p1 <- input_prop  #Expected email open rate in group 1
    
    delta <- input_delta #Expected change in open rate = pn - p1, aka effect size
    
    
    
    
    if(p1+delta>=1)
      return(0)
    else{
      
      #Expected email open rate in group 2 to n
      for(i in 2:n_groups-1){
        assign(paste("p", i, sep = ""), p1+delta/2)    
      }
      
      assign(paste("p", n_groups, sep = ""), p1+delta)    
      
      
      
      #Construct design matrix
      xmat <- expand.grid(rep(list(0:1),n_factors))
      
      
      nsamples <- 1000  #Number of times simulations will be run to calculate power for a given sample size
      
     
      
      
      
      nl<-10
      
      
      
      
      npowerl = 0 #initialize power
      
      power_vector = NULL
      
      for(i in 1:nsamples)
      {
        y<-NULL
        for(j in 1:n_groups)
          y<- c(y,rbinom(1,nl,get(paste("p",j,sep="")) )) #Simulated number of opens in each group
        
        
        y_c <- nl-y                          #Number of not open in each group
        data_matrix<- cbind(y,y_c,xmat)
        fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
        
        p_value <- coef(summary(fit))[,4]    #get p_values
        p_value<-p_value[-1]    
        if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
          npowerl<- npowerl+1
        
      }
      
      
      
      
      nu<- 30000
      npoweru = 0 #initialize power
      
      power_vector = NULL
      
      for(i in 1:nsamples)
      {
        y<-NULL
        for(j in 1:n_groups)
          y<- c(y,rbinom(1,nu,get(paste("p",j,sep="")) ))
        
        y_c <- nu-y                          #Number of not open in each group
        data_matrix<- cbind(y,y_c,xmat)
        fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
        
        p_value <- coef(summary(fit))[,4]    #get p_values
        p_value<-p_value[-1]    
        if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
          npoweru<- npoweru+1
        
      }
      if(npoweru/nsamples <=req_power)
        return(paste(nu,"+"))
      
      else{     #Do binary search
        
        while(1)
        {
          n_mid <- floor((nl+nu)/2)
          
          if(n_mid-nl<=2)
            return(n_mid)
          else{
            
            #sample size of each cell
            npower_mid = 0 #initialize power
            
            power_vector = NULL
            
            for(i in 1:nsamples)
            {
              y<-NULL
              for(j in 1:n_groups)
                y<- c(y,rbinom(1,n_mid,get(paste("p",j,sep="")) ))
              
              y_c <- n_mid-y                          #Number of not open in each group
              data_matrix<- cbind(y,y_c,xmat)
              fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
              
              p_value <- coef(summary(fit))[,4]    #get p_values
              p_value<-p_value[-1]    
              if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
                npower_mid<- npower_mid+1
              
            }
            
            if(npower_mid/nsamples>req_power)
              nu <- n_mid
            else if (npower_mid/nsamples<=req_power)
              nl <- n_mid
            
            
            
          }
        }
        return("ERROR")
        
      }
    }
  }
  
}





shinyApp(ui, server)