library(shiny)



ui <- fluidPage(
  # App title ----
  headerPanel("Sample size calculator for 2x2 full factorial design"),
  
  # Sidebar panel for inputs ----
  sidebarPanel(
    numericInput(inputId = "input_prop",label = "Expected email open rate",value=0.3,min = 0.1,max = 0.9,step = 0.1),
    numericInput(inputId = "input_delta",label = "Expected change in email open rate",value=0.1,min = 0.1,max = 0.9,step = 0.1)
  ),
  
  mainPanel(
    textOutput("y",container = span)
  )
)

server <- function(input, output, session) {
  
  
  
  
  
  output$y<- renderPrint(paste("Sample size required in each group = ",output_function(input$input_prop,input$input_delta)))
  
  output_function<- function(input_prop,input_delta)
  {
    
    
    n_factors <- 2 #Number of factors
    
    n_levels <- 2 #Numbers of levels in each factor
    
    
    
    n_groups <- n_factors*n_levels #Number of cells
    
    p1 <- input_prop  #Expected email open rate in group 1
    
    delta <- input_delta #Expected change in open rate = pn - p1, aka effect size
    
    if(p1+delta>=1)
      return(0)
    else{
      #Expected email open rate in group 2 to n
      for(i in 2:n_groups-1){
        assign(paste("p", i, sep = ""), p1+delta/2)    
      }
      
      assign(paste("p", n_groups, sep = ""), p1+delta)    
      
      
      
      #Construct design matrix
      a<-c(0,1)
      b<-c(0,1)
      xmat <- expand.grid(a=a,b=b)
      
      
      nsamples <- 1000  #Number of times simulations will be run to calculate power for a given sample size
      
      req_power = 0.8
      alpha_level = 0.05
      
      
      
      nl<-2
      
      
      
      
      npowerl = 0 #initialize power
      
      power_vector = NULL
      
      for(i in 1:nsamples)
      {
        y <- rbinom(n_groups,nl,c(p1,p2,p3,p4)) #Simulated number of opens in each group
        y_c <- nl-y                          #Number of not open in each group
        data_matrix<- cbind(y,y_c,xmat)
        fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
        
        p_value <- coef(summary(fit))[,4]    #get p_values
        p_value<-p_value[-1]    
        if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
          npowerl<- npowerl+1
        
      }
      
      
      
      
      nu<- 30000
      npoweru = 0 #initialize power
      
      power_vector = NULL
      
      for(i in 1:nsamples)
      {
        y <- rbinom(n_groups,nu,c(p1,p2,p3,p4)) #Simulated number of opens in each group
        y_c <- nu-y                          #Number of not open in each group
        data_matrix<- cbind(y,y_c,xmat)
        fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
        
        p_value <- coef(summary(fit))[,4]    #get p_values
        p_value<-p_value[-1]    
        if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
          npoweru<- npoweru+1
        
      }
      if(npoweru/nsamples <=req_power)
        return(paste(nu,"+"))
      
      else{
        
        for(j in 1:300)
        {
          n_mid <- floor((nl+nu)/2)
          
          if(n_mid-nl<=2)
            return(n_mid)
          else{
            
            #sample size of each cell
            npower_mid = 0 #initialize power
            
            power_vector = NULL
            
            for(i in 1:nsamples)
            {
              y <- rbinom(n_groups,n_mid,c(p1,p2,p3,p4)) #Simulated number of opens in each group
              y_c <- n_mid-y                          #Number of not open in each group
              data_matrix<- cbind(y,y_c,xmat)
              fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
              
              p_value <- coef(summary(fit))[,4]    #get p_values
              p_value<-p_value[-1]    
              if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
                npower_mid<- npower_mid+1
              
            }
            
            if(npower_mid/nsamples>req_power)
              nu <- n_mid
            else if (npower_mid/nsamples<=req_power)
              nl <- n_mid
            
            
            
          }
        }
        return("ERROR")
        
      }
    }
  }
  
}



shinyApp(ui, server)