# Binomial response full factorial 2 x 2 design



n_factors <- 2 #Number of factors

n_levels <- 2 #Numbers of levels in each factor



n_groups <- n_factors*n_levels #Number of cells

p1 <- 0.2  #Expected email open rate in group 1

delta <- 0.1 #Expected change in open rate = pn - p1, aka effect size

p2 <- p1+delta/2  #Expected email open rate in group 2
p3 <- p1+delta/2  #Expected email open rate in group 3
p4 <- p1 + delta  #Expected email open rate in group 4

#Construct design matrix
a<-c(0,1)
b<-c(0,1)
xmat <- expand.grid(a=a,b=b)


nsamples <- 1000  #Number of times simulations will be run to calculate power for a given sample size

req_power = 0.8
alpha_level = 0.05

ni<-0
npower=0



while((npower/nsamples)<req_power)
{
  ni<-ni+100  #sample size of each cell
  N <- ni*n_factors*n_levels  #Total sample size
  
  
  npower = 0 #initialize power
  
  power_vector = NULL
  
  for(i in 1:nsamples)
  {
    y <- rbinom(n_groups,ni,c(p1,p2,p3,p4)) #Simulated number of opens in each group
    all_y <- rep(ni,n_groups)                
    y_c <- all_y-y                          #Number of not open in each group
    data_matrix<- cbind(y,y_c,xmat)
    fit<- glm(cbind(y,y_c)~.*.,data = data_matrix,family = binomial)  #fit glm logistic
    
    p_value <- coef(summary(fit))[,4]    #get p_values
    p_value<-p_value[-1]    
    if(any(p_value<alpha_level))               #count number of times any p_value< alpha_level   
      npower<- npower+1
    
  }
  
}


paste("Required sample size in each group = ",ni,sep = "")








