library(shiny)
library(DT)
library(highcharter)
library(shinythemes)

empty.vec = rep("", 10)
out.df <- data.frame(n_factor=empty.vec, t_alpha=empty.vec, t_power=empty.vec,
                     op_rate=empty.vec, op_delta=empty.vec, n_sample=empty.vec,
                     stringsAsFactors = FALSE)
