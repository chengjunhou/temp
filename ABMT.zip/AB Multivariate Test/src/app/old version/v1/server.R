source("preserver.R")

shinyServer(function(input, output, session) {



###### Tab 1 ######

RLT <- reactiveValues()
RLT$iii <- 0
RLT$df <- out.df

observeEvent(input$sbmBUT, {
  index = RLT$iii
  index = index + 1
  RLT$iii = index
  temp = RLT$df
  # sample size calculation
  pseudo.bol = TRUE
  withProgress(message = "Calculating...", value = 0.4, {
    size.one = ifelse(pseudo.bol==FALSE, output_function(input$input_prop,input$input_delta,
                                                         input$input_nfactors,input$input_alpha,input$input_power),
                      output_function_pseudo(input$input_prop,input$input_delta,input$input_nfactors,
                                             input$input_alpha,input$input_power))
    setProgress(0.9)
    if (index <= 10) {
      temp[index,] = c(as.character(c(input$input_nfactors, input$input_alpha, input$input_power, 
                                      input$input_prop, input$input_delta)), size.one)
    } else {
      temp = rbind(temp, c(as.character(c(input$input_nfactors, input$input_alpha, input$input_power, 
                                          input$input_prop, input$input_delta)), size.one))
    }
    Sys.sleep(0.5)
    setProgress(1)
  })
  RLT$df = temp
})

observeEvent(input$clrBUT, {
  RLT$iii <- 0
  RLT$df <- out.df
})

output$downloadBUT <- downloadHandler(
  filename = function() {
    paste0("ab_test", ".csv")
  },
  content = function(file) {
    print(dim(RLT$df))
    write.csv(RLT$df, file, row.names=FALSE)
  }
)


output$tableVIEW <- DT::renderDataTable({
  temp = RLT$df
  DT::datatable(temp, rownames=T,
                options = list(pageLength=5, dom='tip',
                               columnDefs=list(list(className='dt-right', targets=1:6))))
})


output$barPLOT <- renderHighchart({
  index = RLT$iii
  if (index > 0) {
    temp = RLT$df
    zxc = temp[1:index,4:6]
    zxc = data.frame(lapply(zxc,as.numeric))
    zxc$trial = rownames(zxc)
    h1 <- highchart() %>%
      hc_xAxis(categories=zxc$trial) %>%
      hc_add_series(name="rate change", data=zxc$op_delta) %>%
      hc_add_series(name="open rate", data=zxc$op_rate) %>%
      hc_chart(type="column", zoomType="x") %>%
      hc_plotOptions(series=list(stacking=TRUE))
    h1
  }
})

output$lnePLOT <- renderHighchart({
  index = RLT$iii
  if (index > 0) {
    temp = RLT$df
    zxc = temp[1:index,4:6]
    zxc = data.frame(lapply(zxc,as.numeric))
    zxc$trial = rownames(zxc)
    h2 <- highchart() %>%
      hc_xAxis(categories =zxc$trial) %>%
      hc_add_series(name="sample size", data=zxc$n_sample) %>%
      hc_chart(type="line", zoomType="x")
    h2
  }
})



###### Tab 2 ######

mydata <- reactive({
  inFile <- input$file1
  if (is.null(inFile)) {
    return(NULL) 
  } else {
    tbl <- read.csv(inFile$datapath, header=input$header, sep=input$sep)
    lenvec = apply(tbl,2, function(x) length(unique(x)))
    if (all(lenvec[1:(length(lenvec)-2)]==2)) {
      index = which(unname(lapply(tbl, class))=="factor")
      tbl[,index] = data.frame(lapply(tbl[,index], as.integer)) - 1
      return(tbl) 
    } else {
      return(NULL)
    }
  }
})


output$rest_var_select <- renderUI({
  if (is.null(mydata())) {
    return(NULL)
  } else {
    factors_data = ncol(mydata())-2
    covariates_choose = names(mydata())[1:factors_data]
    checkboxGroupInput("other_var_select","Selected Factors", 
                       choices=as.list(covariates_choose), selected=as.list(covariates_choose))
  }
})


model_fit <- reactive({
  all_data = mydata()
  factors_data = ncol(all_data)-2
  
  open_y = all_data[,(factors_data+1)]
  y_c = all_data[,(factors_data+2)]-open_y
  
  if (length(input$other_var_select)>1) {
    xmat = all_data[,input$other_var_select]
  } else {
    xmat = data.frame(all_data[,input$other_var_select])
    names(xmat) = input$other_var_select
  }
  data_matrix<- cbind(xmat,open_y,y_c)
  model_f<-glm(cbind(open_y,y_c)~.*.,data = data_matrix,family = binomial)
  return(model_f)
})

output$model_summary <- renderPrint({
  if (is.null(mydata())) {
    return("No file is selected or data issue")
  }
  summary(model_fit())
})

output$condWELA1 <- renderUI({
  if(input$collaCHK==FALSE){
    verbatimTextOutput("model_summary")
  }
})
output$condWELA2 <- renderUI({
  if(input$collaCHK==TRUE){
    wellPanel()
  }
})


output$best_comb <- renderTable({
  all_data = mydata()
  factors_data = ncol(all_data)-2
  open_y = all_data[,(factors_data+1)]
  
  xmat = all_data[,input$other_var_select]
  if (length(input$other_var_select)>1) {
    pred = predict(model_fit(),xmat)
    max_index = which.max(pred)
    xmat[max_index,]
  }
  else if (length(input$other_var_select)==1) {
    ag_data<-aggregate(open_y,by=list(Category=xmat),FUN=sum)
    maxlevel = ag_data[which.max(ag_data[,2]),1]
    zxc = data.frame(zxc=maxlevel)
    names(zxc) = input$other_var_select
    zxc
  }
  else {
    return("") 
  }
})


output$predicted_ci <- renderPrint({
  if (is.null(mydata())) {
    return("No file is selected or data issue")
  }
  
  all_data = mydata()
  factors_data = ncol(all_data)-2
  xmat = all_data[,input$other_var_select]
  preds = predict(model_fit(),xmat,type="link",se.fit=TRUE)
  # 
  max_index<- which.max(preds$fit)
  # 
  critval <- 1.96 ## approx 95% CI
  upr <- preds$fit + (critval * preds$se.fit)
  lwr <- preds$fit - (critval * preds$se.fit)
  upr2 <- model_fit()$family$linkinv(upr)[max_index]
  lwr2 <- model_fit()$family$linkinv(lwr)[max_index]
  #
  textvec = c("95% open rate CI for best combination of factors", paste0("(",signif(lwr2,5),", ",signif(upr2,5),")"))
  #textvec
  t(t(textvec))
})

output$condWELB1 <- renderUI({
  if(input$collbCHK==FALSE){
    tagList(wellPanel(
      h5("Best Combination of Factors"),
      tableOutput("best_comb"),
      h5("Open Rate Confidence Interval"),
      verbatimTextOutput("predicted_ci")
    ))
  }
})
output$condWELB2 <- renderUI({
  if(input$collbCHK==TRUE){
    wellPanel()
  }
})

})