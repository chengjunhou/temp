
shinyUI(navbarPage("A/B Testing Tool", theme=shinytheme("cerulean"),
                   
                   
tabPanel("Sample Size Calculator", icon = icon("calculator"), 
         
  sidebarPanel(
    sliderInput(inputId="input_nfactors", label="Number of Factors", value=1, min=1, max=5, step=1),
    sliderInput(inputId="input_alpha", label="Test Significance (alpha)", value=0.05,min=0.01,max=0.1,step=0.01),
    sliderInput(inputId="input_power", label = "Test Power (1-beta)", value=0.8,min=0.2,max=0.9,step=0.1),
    hr(),
    numericInput(inputId="input_prop", label = "Base Email Conversion Rate", value=0.3,min=0.1,max=0.9,step=0.1),
    numericInput(inputId="input_delta", label = "Minimum Change in Conversion Rate", value=0.1,min=0.1,max=0.9,step = 0.1),
    htmlOutput("min_change_cov"),
    hr(),
    fluidRow(
      column(6, actionButton("sbmBUT", "Submit", icon=icon("check"))),
      column(6, actionButton("clrBUT", "Clear-all", icon=icon("close")))
      ),
    hr(),
    downloadButton("downloadBUT", "Download Data")
  ),
  
  mainPanel(
    fluidRow(
      column(12, aligh="center", DT::dataTableOutput("tableVIEW"))
    ),
    hr(),
    highchartOutput("barPLOT", height = "300px"),
    highchartOutput("lnePLOT", height = "300px")
  ) #mainPanel
), #tabPanel


tabPanel("Multivariate Test", icon = icon("flask"), 
         
  sidebarPanel(
    fileInput('file1', 'Choose CSV File',
              accept=c('text/csv', 'text/comma-separated- values,text/plain', '.csv')),
    hr(),
    checkboxInput('header', 'Read Header', TRUE),
    radioButtons('sep',  'Separator', c(Comma=',', Semicolon=';', Tab='\t')),
    hr(),
    uiOutput("rest_var_select"),
    hr(),
    htmlOutput("guidelines")
    
  ),
  
  mainPanel(
    h3("Model Summary:"),
    checkboxInput("collaCHK", label = "Show Model Detials", value = FALSE),
    wellPanel(tableOutput("model_sumtab")),
    uiOutput("condWELA1"),
    uiOutput("condWELA2"),
    h3("Prediction Summary:"),
    # checkboxInput("collbCHK", label = "Collapse Display", value = FALSE),
    # uiOutput("condWELB1"),
    # uiOutput("condWELB2")
    wellPanel(
      h5("Best Combination of Factors"),
      tableOutput("best_comb"),
      h5("Open Rate Confidence Interval"),
      htmlOutput("predicted_ci")
    )
  )
  
) #tabPanel

))
                            